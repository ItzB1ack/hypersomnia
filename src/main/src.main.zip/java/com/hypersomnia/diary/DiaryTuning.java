package com.hypersomnia.diary;

import java.util.Map;

/** Числа дневника. Общий код, без клиентских импортов. Страница 0 = хронология, 1..PAGES = свободные страницы. */
public final class DiaryTuning {
    private DiaryTuning() {}

    public static final int PAGES = 11;
    /** Одна страница книги (разворот = две). */
    public static final int PAPER_W = 170;
    public static final int PAPER_H = 230;
    /** Размер положенного листа на странице (единицы бумаги). */
    public static final int THUMB_W = 54;
    public static final int THUMB_H = 72;
    /** Минимальный размер вписанной миниатюры (для ограничения на сервере). */
    public static final int THUMB_MIN = 8;
    /** Фотографии как отдельные элементы листа (не страницы): id элемента -> печать. */
    public record Photo(String tex, String source, int texW, int texH) {}
    public static final Map<String, Photo> PHOTOS = Map.of(
            "photo_staff", new Photo("photo_staff", "mem_1_photo", 176, 132));
    /** Ширина печати на листе в единицах бумаги; высота считается по пропорции текстуры. */
    public static final int PHOTO_W = 130;
    public static final int MAX_ENTRIES = 48;
    /** Сдвиг мыши (px), после которого перетаскивание по странице листает её. */
    public static final int FLIP_THRESHOLD_PX = 40;
    /** Второй разворот, левая страница (2-3): таблица «буква -> знак», которую игрок заполняет сам. Кладут только фотографии. */
    public static final int KEY_PAGE = 2;
}