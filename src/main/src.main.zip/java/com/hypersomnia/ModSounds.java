package com.hypersomnia;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModSounds {
    private ModSounds() {}

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, Hypersomnia.MOD_ID);

    public static final DeferredHolder<SoundEvent, SoundEvent> BREATH_EXHALE =
            SOUNDS.register("breath_exhale", () -> SoundEvent.createVariableRangeEvent(
                    ResourceLocation.fromNamespaceAndPath(Hypersomnia.MOD_ID, "breath_exhale")));

    public static void register(IEventBus bus) {
        SOUNDS.register(bus);
    }
}