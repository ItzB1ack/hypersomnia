package com.hypersomnia.lab;

/**
 * Числа лаборатории. Остановки лифта (stop): 0 = поверхность (павильон), 1..5 = этажи B1..B5.
 * Чертежи: data/hypersomnia/lab/{real|dream}_{g|b1..b5}.txt; этаж без чертежа не строится.
 */
public final class LabTuning {
    private LabTuning() {}

    public static final int STOPS = 6;

    // ---- Вертикаль ----
    /** Y пола B1 (первый блок воздуха над полом). Дальше вниз с шагом PITCH. */
    public static final int B1_Y = 20;
    public static final int PITCH = 8;

    public static int floorY(int stop) {
        return B1_Y - (stop - 1) * PITCH;
    }

    public static String stopLabel(int stop) {
        return stop == 0 ? "G" : "B" + stop;
    }

    public static String blueprintName(boolean dream, int stop) {
        return (dream ? "dream_" : "real_") + (stop == 0 ? "g" : "b" + stop);
    }

    // ---- Место и момент стройки ----
    public static final int DIST_MIN = 300;
    public static final int DIST_MAX = 500;
    public static final int BUILD_RADIUS = 160;
    public static final int CHECK_EVERY = 100;
    /** Кандидатов на проход (проходов два: второй с более широким кольцом). */
    public static final int ATTEMPTS = 96;
    public static final long SEED_SALT = 0x4C4142_0047L;

    // ---- Поиск места (по рельефу генератора, относительно клетки '@') ----
    /** Площадка выборки: x -12..12, z -8..14 с шагом 4 (накрывает павильон и двор). */
    public static final int SAMPLE_X1 = -12;
    public static final int SAMPLE_X2 = 12;
    public static final int SAMPLE_Z1 = -8;
    public static final int SAMPLE_Z2 = 14;
    public static final int SAMPLE_STEP = 4;
    /** Берём сразу, если перепад высот не больше SPREAD_OK; иначе лучший из прошедших, но не хуже SPREAD_MAX. */
    public static final int SPREAD_OK = 2;
    public static final int SPREAD_MAX = 5;
    /** Кандидат с перепадом больше SPREAD_REJECT отбрасывается сразу. */
    public static final int SPREAD_REJECT = 12;
    /** Допустимая высота земли над уровнем моря. */
    public static final int MIN_ABOVE_SEA = 3;
    public static final int MAX_ABOVE_SEA = 40;
    /** Не ставим лабораторию ближе этого расстояния к деревне (блоки). */
    public static final int VILLAGE_CLEAR_BLOCKS = 128;

    // ---- Подготовка площадки поверхности ----
    /** Мощёный двор вокруг здания (блоки). */
    public static final int YARD = 3;
    /** Уровень двора — этот процентиль высот площадки (0.7 = ближе к верхней стороне, меньше выкапываем). */
    public static final double PAD_PERCENTILE = 0.7;
    /** Глубина подсыпки под площадкой. */
    public static final int FILL_DEPTH = 24;
    /** Длина входной дорожки за подпорной стенкой (блоки), по 1 блоку подъёма/спуска на шаг. */
    public static final int ENTRY_PATH = 6;
    /** Подпорная стенка поднимается над полом не выше этого (блоки); выше остаётся естественный срез рельефа. */
    public static final int WALL_MAX_ABOVE = 1;

    // ---- Замки ----
    public static final int CODE_DIGITS = 4;
    public static final int KEYPAD_MAX_DIST = 6;
    public static final int KEYPAD_DENIED_TICKS = 30;
    public static final int KEYPAD_GRANTED_TICKS = 20;
    public static final int LOCK_HATCH = 1;

    /** Код замка lock в мире. Реальный: время последней записи в журнале (02:41). Мир снов: 03:13. */
    public static int lockCode(int lock, boolean dream) {
        return switch (lock) {
            case LOCK_HATCH -> dream ? 313 : 241;
            default -> -1;
        };
    }

    // ---- Павильон: фасад ----
    /** Пилястры на фасаде на 1/4 и 3/4 длины стороны. */
    public static final double PILASTER_FRACTION = 0.25;
    /** Редкие «заплатки» ремонта: 1 из N блоков поля — каменный кирпич (0 = выключено). */
    public static final int PATCH_REAL = 61;
    public static final int PATCH_DREAM = 43;
    /** Трещины: 1 из N блоков поля. */
    public static final int CRACKS_REAL = 149;
    public static final int CRACKS_DREAM = 83;
    /** Мир снов: 1 из N блоков поля — камень, которого в этом здании нет (0 = выключено). */
    public static final int WRONG_DREAM = 211;

    // ---- Антенна-тарелка на крыше (задел под загадку) ----
    /** Сколько блоков над крышей стирать при пересборке (парапет, будка, тарелка). */
    public static final int ROOF_CLEAR = 11;
    /** Шаг столбиков ограды крыши: каждый N-й блок — столбик (плюс все углы). */
    public static final int PARAPET_POST_EVERY = 4;

    // ---- Рельеф плоской крыши (без скатов) ----
    /** Высота машинного помещения над кабиной лифта. */
    public static final int MACHINE_HEIGHT = 2;
    /** Отступ люков от углов крыши. */
    public static final int ROOF_HATCH_INSET = 3;

    // ---- Лифт ----
    public static final int LIFT_BASE_TICKS = 50;
    public static final int LIFT_PER_FLOOR = 16;
}
