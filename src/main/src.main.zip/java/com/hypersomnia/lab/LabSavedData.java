package com.hypersomnia.lab;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.LinkedHashMap;
import java.util.Map;

/** Данные лаборатории в одном мире (по одной на ServerLevel). Точка входа (sited/site*) живёт только в данных Верхнего мира. */
public final class LabSavedData extends SavedData {
    private static final String NAME = "hypersomnia_lab2";
    public static final int KIND_LIFT = 1;
    public static final int KIND_LOCK = 2;

    // ---- Точка входа (Верхний мир) ----
    public boolean sited;
    public int siteX;
    public int siteZ;
    /** Номер переброса места (команда resite): меняет выбор при том же seed. */
    public int siteTry;

    // ---- Состояние мира ----
    public boolean built;
    public boolean dream;
    /** Мировые x, z центра кабины '@' и y земли у павильона. */
    public int originX;
    public int originZ;
    public int groundY;
    /** Бит n = остановка n построена. */
    public int builtMask;
    /** Старший открытый этаж (0 = только поверхность). */
    public int reached;
    /** Бит id = замок id открыт. */
    public int locksOpen;
    /** Остановка с закрытыми во время рейса дверями или -1. */
    public int closedDoor = -1;
    /** Антенна-тарелка: центр (упакованный BlockPos) и текущий угол поворота (задел под загадку). */
    public long dishPos;
    public int dishAngle;
    public int[] stopY = new int[LabTuning.STOPS];
    public int[] stopH = new int[LabTuning.STOPS];
    public int[] bbox = new int[LabTuning.STOPS * 4];
    public long[] door = new long[LabTuning.STOPS];
    /** Интерактивные таблички: позиция -> kind * 1000 + id. */
    public final Map<Long, Integer> inter = new LinkedHashMap<>();

    public static LabSavedData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(
                new SavedData.Factory<>(LabSavedData::new, LabSavedData::load, null), NAME);
    }

    public boolean isBuilt(int stop) {
        return stop >= 0 && stop < LabTuning.STOPS && ((builtMask >> stop) & 1) != 0;
    }

    public boolean isLockOpen(int id) {
        return ((locksOpen >> id) & 1) != 0;
    }

    /** Позиция таблички замка id или null. */
    public BlockPos lockPos(int id) {
        for (Map.Entry<Long, Integer> e : inter.entrySet())
            if (e.getValue() == KIND_LOCK * 1000 + id) return BlockPos.of(e.getKey());
        return null;
    }

    public void resetBuild() {
        built = false;
        builtMask = 0;
        closedDoor = -1;
        inter.clear();
        setDirty();
    }

    public void resetProgress() {
        reached = 0;
        locksOpen = 0;
        setDirty();
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider provider) {
        tag.putBoolean("sited", sited);
        tag.putInt("siteX", siteX);
        tag.putInt("siteZ", siteZ);
        tag.putInt("siteTry", siteTry);
        tag.putBoolean("built", built);
        tag.putBoolean("dream", dream);
        tag.putInt("originX", originX);
        tag.putInt("originZ", originZ);
        tag.putInt("groundY", groundY);
        tag.putInt("builtMask", builtMask);
        tag.putInt("reached", reached);
        tag.putInt("locksOpen", locksOpen);
        tag.putInt("closedDoor", closedDoor);
        tag.putLong("dishPos", dishPos);
        tag.putInt("dishAngle", dishAngle);
        tag.putIntArray("stopY", stopY);
        tag.putIntArray("stopH", stopH);
        tag.putIntArray("bbox", bbox);
        tag.putLongArray("door", door);
        long[] keys = new long[inter.size()];
        int[] vals = new int[inter.size()];
        int i = 0;
        for (Map.Entry<Long, Integer> e : inter.entrySet()) {
            keys[i] = e.getKey();
            vals[i++] = e.getValue();
        }
        tag.putLongArray("interKeys", keys);
        tag.putIntArray("interVals", vals);
        return tag;
    }

    private static LabSavedData load(CompoundTag tag, HolderLookup.Provider provider) {
        LabSavedData d = new LabSavedData();
        d.sited = tag.getBoolean("sited");
        d.siteX = tag.getInt("siteX");
        d.siteZ = tag.getInt("siteZ");
        d.siteTry = tag.getInt("siteTry");
        d.built = tag.getBoolean("built");
        d.dream = tag.getBoolean("dream");
        d.originX = tag.getInt("originX");
        d.originZ = tag.getInt("originZ");
        d.groundY = tag.getInt("groundY");
        d.builtMask = tag.getInt("builtMask");
        d.reached = tag.getInt("reached");
        d.locksOpen = tag.getInt("locksOpen");
        d.closedDoor = tag.contains("closedDoor") ? tag.getInt("closedDoor") : -1;
        d.dishPos = tag.getLong("dishPos");
        d.dishAngle = tag.getInt("dishAngle");
        int[] a = tag.getIntArray("stopY");
        if (a.length == d.stopY.length) d.stopY = a;
        a = tag.getIntArray("stopH");
        if (a.length == d.stopH.length) d.stopH = a;
        a = tag.getIntArray("bbox");
        if (a.length == d.bbox.length) d.bbox = a;
        long[] l = tag.getLongArray("door");
        if (l.length == d.door.length) d.door = l;
        long[] keys = tag.getLongArray("interKeys");
        int[] vals = tag.getIntArray("interVals");
        for (int i = 0; i < keys.length && i < vals.length; i++) d.inter.put(keys[i], vals[i]);
        return d;
    }
}
