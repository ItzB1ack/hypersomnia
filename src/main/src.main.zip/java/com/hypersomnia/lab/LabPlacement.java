package com.hypersomnia.lab;

import com.hypersomnia.Hypersomnia;
import com.hypersomnia.dream.DreamDimension;
import com.mojang.logging.LogUtils;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import org.slf4j.Logger;


/** Одна точка входа на оба мира; лаборатория строится, когда игрок подходит ближе BUILD_RADIUS. */
@EventBusSubscriber(modid = Hypersomnia.MOD_ID)
public final class LabPlacement {
    private LabPlacement() {}

    private static final Logger LOGGER = LogUtils.getLogger();

    @SubscribeEvent
    public static void onTick(ServerTickEvent.Post event) {
        MinecraftServer server = event.getServer();
        if (server.getTickCount() % LabTuning.CHECK_EVERY != 0) return;
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            ServerLevel level = p.serverLevel();
            boolean dream = level.dimension() == DreamDimension.LEVEL;
            if (!dream && level.dimension() != Level.OVERWORLD) continue;
            if (LabSavedData.get(level).built) continue;
            BlockPos site = site(server);
            double dx = p.getX() - site.getX(), dz = p.getZ() - site.getZ();
            if (dx * dx + dz * dz > (double) LabTuning.BUILD_RADIUS * LabTuning.BUILD_RADIUS) continue;
            build(level, site, dream);
            return;
        }
    }

    /** Выбор места заранее, пока идёт загрузка мира: поиск по рельефу занимает заметное время. */
    @SubscribeEvent
    public static void onStarted(ServerStartedEvent event) {
        site(event.getServer());
    }

    /** Координаты входа (x, z), общие для обоих миров. Выбираются один раз (LabSiteFinder), хранятся в Верхнем мире. */
    public static BlockPos site(MinecraftServer server) {
        ServerLevel ow = server.overworld();
        LabSavedData d = LabSavedData.get(ow);
        if (!d.sited) {
            BlockPos p = LabSiteFinder.find(ow, d.siteTry);
            d.sited = true;
            d.siteX = p.getX();
            d.siteZ = p.getZ();
            d.setDirty();
        }
        return new BlockPos(d.siteX, 0, d.siteZ);
    }

    /** Высота земли в точке (первый воздух над землёй, без листвы). */
    public static int ground(ServerLevel level, int x, int z) {
        return level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
    }

    /** Строит все этажи, для которых есть чертёж. Ошибка чертежа не роняет сервер, но пишется в лог. */
    public static void build(ServerLevel level, BlockPos site, boolean dream) {
        LabSavedData d = LabSavedData.get(level);
        d.resetBuild();
        // Уровень двора не пересчитываем при пересборке на том же месте: иначе площадка «ползёт» вверх.
        boolean sameSite = d.groundY != 0 && d.originX == site.getX() && d.originZ == site.getZ();
        d.dream = dream;
        d.originX = site.getX();
        d.originZ = site.getZ();
        try {
            for (int n = 0; n < LabTuning.STOPS; n++) {
                String name = LabTuning.blueprintName(dream, n);
                if (!LabBlueprint.exists(name)) continue;
                LabBlueprint bp = LabBlueprint.get(name);
                int fy;
                if (n == 0) {
                    fy = sameSite ? d.groundY : LabBuilder.padLevel(level, bp, site.getX(), site.getZ());
                    d.groundY = fy;
                } else {
                    fy = LabTuning.floorY(n);
                }
                LabBuilder.build(level, bp, site.getX(), site.getZ(), fy, n, n == 0, d);
            }
            LabLift.refreshDoors(level, d);
            LabLocks.refreshSigns(level, d);
        } catch (RuntimeException e) {
            LOGGER.error("Lab build failed", e);
        }
        d.built = true;
        d.setDirty();
    }
}
