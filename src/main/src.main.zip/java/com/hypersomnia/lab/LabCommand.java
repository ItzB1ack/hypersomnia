package com.hypersomnia.lab;

import com.hypersomnia.Hypersomnia;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import com.hypersomnia.dream.DreamDimension;

/**
 * /hypersomnia_lab where | tp | status | rebuild | resite | unlock <0-5> | lock <id> open.
 * rebuild: стирает старую постройку этого мира, сбрасывает прогресс и строит заново по чертежам.
 */
@EventBusSubscriber(modid = Hypersomnia.MOD_ID)
public final class LabCommand {
    private LabCommand() {}

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("hypersomnia_lab")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("where").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    BlockPos site = LabPlacement.site(p.server);
                    LabSavedData d = LabSavedData.get(p.serverLevel());
                    ctx.getSource().sendSuccess(() -> Component.literal("Lab entrance x=" + site.getX() + " z=" + site.getZ()
                            + ", built in this world: " + d.built), false);
                    return 1;
                }))
                .then(Commands.literal("tp").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    BlockPos site = LabPlacement.site(p.server);
                    ServerLevel level = p.serverLevel();
                    int z = site.getZ() + 12;
                    int y = LabPlacement.ground(level, site.getX(), z);
                    p.teleportTo(site.getX() + 0.5, y, z + 0.5);
                    return 1;
                }))
                .then(Commands.literal("status").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    LabSavedData d = LabSavedData.get(p.serverLevel());
                    ctx.getSource().sendSuccess(() -> Component.literal("built=" + d.built + " dream=" + d.dream
                            + " builtMask=" + Integer.toBinaryString(d.builtMask) + " reached=" + d.reached
                            + " locks=" + Integer.toBinaryString(d.locksOpen) + " origin=" + d.originX + "," + d.originZ
                            + " groundY=" + d.groundY), false);
                    return 1;
                }))
                .then(Commands.literal("rebuild").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    ServerLevel level = p.serverLevel();
                    boolean dream = level.dimension() == DreamDimension.LEVEL;
                    if (!dream && level.dimension() != Level.OVERWORLD) {
                        ctx.getSource().sendFailure(Component.literal("Only in Overworld or dream"));
                        return 0;
                    }
                    LabSavedData d = LabSavedData.get(level);
                    for (int n = 0; n < LabTuning.STOPS; n++) LabBuilder.clear(level, d, n);
                    d.resetProgress();
                    LabPlacement.build(level, LabPlacement.site(p.server), dream);
                    ctx.getSource().sendSuccess(() -> Component.literal("Lab rebuilt (" + (dream ? "dream" : "real")
                            + "), mask=" + Integer.toBinaryString(d.builtMask)), false);
                    return 1;
                }))
                .then(Commands.literal("resite").executes(ctx -> {
                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                    ServerLevel level = p.serverLevel();
                    boolean dream = level.dimension() == DreamDimension.LEVEL;
                    if (!dream && level.dimension() != Level.OVERWORLD) {
                        ctx.getSource().sendFailure(Component.literal("Only in Overworld or dream"));
                        return 0;
                    }
                    LabSavedData d = LabSavedData.get(level);
                    for (int n = 0; n < LabTuning.STOPS; n++) LabBuilder.clear(level, d, n);
                    d.resetProgress();
                    LabSavedData ow = LabSavedData.get(p.server.overworld());
                    ow.sited = false;
                    ow.siteTry++;
                    ow.groundY = 0;
                    d.groundY = 0;
                    ow.setDirty();
                    BlockPos site = LabPlacement.site(p.server);
                    LabPlacement.build(level, site, dream);
                    int z = site.getZ() + 12;
                    p.teleportTo(site.getX() + 0.5, LabPlacement.ground(level, site.getX(), z), z + 0.5);
                    ctx.getSource().sendSuccess(() -> Component.literal("New site x=" + site.getX() + " z=" + site.getZ()
                            + " (try " + ow.siteTry + "). Run rebuild in the other world."), false);
                    return 1;
                }))
                .then(Commands.literal("unlock")
                        .then(Commands.argument("stop", IntegerArgumentType.integer(0, LabTuning.STOPS - 1)).executes(ctx -> {
                            ServerPlayer p = ctx.getSource().getPlayerOrException();
                            ServerLevel level = p.serverLevel();
                            LabSavedData d = LabSavedData.get(level);
                            d.reached = IntegerArgumentType.getInteger(ctx, "stop");
                            LabLift.refreshDoors(level, d);
                            d.setDirty();
                            ctx.getSource().sendSuccess(() -> Component.literal("reached=" + d.reached), false);
                            return 1;
                        })))
                .then(Commands.literal("lock")
                        .then(Commands.argument("id", IntegerArgumentType.integer(1, 9))
                                .then(Commands.literal("open").executes(ctx -> {
                                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                                    ServerLevel level = p.serverLevel();
                                    LabLocks.grant(level, LabSavedData.get(level), IntegerArgumentType.getInteger(ctx, "id"));
                                    return 1;
                                })))));
    }
}
