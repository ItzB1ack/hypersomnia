package com.hypersomnia.lab;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * ASCII-чертёж этажа. Формат файла:
 * <pre>
 * style real|dream
 * height 5
 * ---
 * (сетка: строка = z сверху вниз, колонка = x слева направо; север сверху)
 * ---
 * sign 1 = LINE1|LINE2|LINE3|LINE4
 * lock K = 1
 * </pre>
 * Символы сетки: см. {@link LabBuilder}. '@' = центр кабины лифта (общая точка выравнивания этажей).
 */
public final class LabBlueprint {
    private static final String BASE = "/data/hypersomnia/lab/";
    private static final Map<String, LabBlueprint> CACHE = new HashMap<>();

    public final String name;
    public final boolean dream;
    public final int height;
    public final int w;
    public final int d;
    public final int ax;
    public final int az;
    public final Map<Character, String[]> signs = new HashMap<>();
    public final Map<Character, Integer> locks = new HashMap<>();
    private final char[][] grid;

    private LabBlueprint(String name, boolean dream, int height, char[][] grid, int w, int d, int ax, int az) {
        this.name = name;
        this.dream = dream;
        this.height = height;
        this.grid = grid;
        this.w = w;
        this.d = d;
        this.ax = ax;
        this.az = az;
    }

    public static boolean exists(String name) {
        return LabBlueprint.class.getResource(BASE + name + ".txt") != null;
    }

    public static synchronized LabBlueprint get(String name) {
        LabBlueprint bp = CACHE.get(name);
        if (bp == null) {
            bp = load(name);
            CACHE.put(name, bp);
        }
        return bp;
    }

    /** Символ клетки; за пределами сетки пробел (пусто). */
    public char at(int x, int z) {
        if (z < 0 || z >= d || x < 0 || x >= w) return ' ';
        return grid[z][x];
    }

    private static LabBlueprint load(String name) {
        try (InputStream in = LabBlueprint.class.getResourceAsStream(BASE + name + ".txt")) {
            if (in == null) throw new IllegalStateException("Lab blueprint not found: " + name);
            BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            List<String> rows = new ArrayList<>();
            Map<Character, String[]> signs = new HashMap<>();
            Map<Character, Integer> locks = new HashMap<>();
            boolean dream = false;
            int height = 5;
            int section = 0;
            String line;
            while ((line = r.readLine()) != null) {
                if (line.endsWith("\r")) line = line.substring(0, line.length() - 1);
                if (line.equals("---")) {
                    section++;
                    continue;
                }
                if (section == 1) {
                    rows.add(line);
                    continue;
                }
                String t = line.trim();
                if (t.isEmpty() || t.startsWith(";")) continue;
                if (section == 0) {
                    if (t.startsWith("style ")) dream = t.substring(6).trim().equals("dream");
                    else if (t.startsWith("height ")) height = Integer.parseInt(t.substring(7).trim());
                } else {
                    int eq = t.indexOf('=');
                    if (eq < 0) continue;
                    String key = t.substring(0, eq).trim();
                    String val = t.substring(eq + 1).trim();
                    if (key.startsWith("sign ")) signs.put(key.substring(5).trim().charAt(0), val.split("\\|", -1));
                    else if (key.startsWith("lock ")) locks.put(key.substring(5).trim().charAt(0), Integer.parseInt(val));
                }
            }
            int w = 0;
            for (String s : rows) w = Math.max(w, s.length());
            int d = rows.size();
            char[][] grid = new char[d][w];
            int ax = -1, az = -1;
            for (int z = 0; z < d; z++) {
                String s = rows.get(z);
                for (int x = 0; x < w; x++) {
                    char c = x < s.length() ? s.charAt(x) : ' ';
                    grid[z][x] = c;
                    if (c == '@') {
                        ax = x;
                        az = z;
                    }
                }
            }
            if (ax < 0) throw new IllegalStateException("Lab blueprint " + name + ": no '@' cell");
            LabBlueprint bp = new LabBlueprint(name, dream, height, grid, w, d, ax, az);
            bp.signs.putAll(signs);
            bp.locks.putAll(locks);
            return bp;
        } catch (IOException e) {
            throw new IllegalStateException("Lab blueprint " + name + ": " + e.getMessage(), e);
        }
    }
}
