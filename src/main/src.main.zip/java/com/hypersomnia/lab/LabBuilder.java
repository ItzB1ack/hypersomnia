package com.hypersomnia.lab;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.Arrays;

/**
 * Строит один этаж по чертежу. Легенда символов:
 * <pre>
 * ' '  пусто (не трогаем)        #  стена от пола до потолка
 * .    пол                        =  проём 3 высотой (перемычка выше)
 * L    пол кабины                 @  центр кабины (пол кабины)
 * Y    пол кабины + лампа         l  дверь кабины лифта (3 высотой, решётка, когда закрыта)
 * *    пол + лампа в потолке      E  пол кабины + табличка-панель лифта
 * T    стол (плита)               R  стеллаж (2 высотой)       U  бочка
 * 1-9  настенная табличка из блока sign    K, J  табличка замка (id из блока lock)
 * </pre>
 * Табличка (1-9, E, K, J) стоит на клетке пола на высоте 1 и крепится к первой найденной стене (порядок С, Ю, В, З).
 */
public final class LabBuilder {
    private LabBuilder() {}

    private static final BlockState AIR = Blocks.AIR.defaultBlockState();

    private record Style(BlockState wall, BlockState patch, BlockState cracked, BlockState wrong,
                         BlockState trim, BlockState floor, BlockState floor2, BlockState roof,
                         int patchEvery, int crackEvery, int wrongEvery) {}

    /**
     * Палитра общая для обоих миров: исследовательский центр — каменный кирпич с тёмной
     * сланцевой отделкой и шахматным каменным полом. Мир снов — те же блоки, только чаще
     * заплатки/трещины и редкий «чужой» блок в стене.
     */
    private static Style style(boolean dream) {
        BlockState wall = Blocks.STONE_BRICKS.defaultBlockState();
        BlockState trim = Blocks.DEEPSLATE_TILES.defaultBlockState();
        BlockState floor = Blocks.SMOOTH_STONE.defaultBlockState();
        BlockState floor2 = Blocks.POLISHED_ANDESITE.defaultBlockState();
        BlockState roof = Blocks.DEEPSLATE_TILES.defaultBlockState();
        if (dream) {
            return new Style(wall, Blocks.CHISELED_STONE_BRICKS.defaultBlockState(), Blocks.CRACKED_STONE_BRICKS.defaultBlockState(),
                    Blocks.DEEPSLATE_BRICKS.defaultBlockState(), trim, floor, floor2, roof,
                    LabTuning.PATCH_DREAM, LabTuning.CRACKS_DREAM, LabTuning.WRONG_DREAM);
        }
        return new Style(wall, Blocks.CHISELED_STONE_BRICKS.defaultBlockState(), Blocks.CRACKED_STONE_BRICKS.defaultBlockState(),
                wall, trim, floor, floor2, roof,
                LabTuning.PATCH_REAL, LabTuning.CRACKS_REAL, 0);
    }

    /** Блок стены: одинаков при каждой перестройке (хэш от координат, без Random). */
    private static BlockState wallAt(Style s, int x, int y, int z) {
        int hsh = Math.floorMod(x * 31 + y * 17 + z * 7, 1440);
        if (s.wrongEvery > 0 && Math.floorMod(hsh, s.wrongEvery) == 0) return s.wrong;
        if (s.patchEvery > 0 && Math.floorMod(hsh, s.patchEvery) == 0) return s.patch;
        if (s.crackEvery > 0 && Math.floorMod(hsh, s.crackEvery) == 0) return s.cracked;
        return s.wall;
    }


    /** Холодная «трубка дневного света»: торцевой стержень, белый свет без зелёного оттенка моря. */
    private static BlockState rod(Direction pointing) {
        return Blocks.END_ROD.defaultBlockState().setValue(net.minecraft.world.level.block.EndRodBlock.FACING, pointing); // [проверить: EndRodBlock.FACING]
    }

    /** Фасад павильона (только поверхность): пилястры и антенна над входом. */
    private static void facade(ServerLevel lv, Style s, int fy, int h, int x1, int z1, int x2, int z2, int[] door) {
        pilaster(lv, s, fy, h, x1, z1); // углы — тёмные столбы во всю высоту
        pilaster(lv, s, fy, h, x2, z1);
        pilaster(lv, s, fy, h, x1, z2);
        pilaster(lv, s, fy, h, x2, z2);
        boolean doorOnZ = door[0] >= 0 && (door[2] == z1 || door[2] == z2);
        boolean doorOnX = door[0] >= 0 && (door[0] == x1 || door[0] == x2);
        double f = LabTuning.PILASTER_FRACTION;
        int aX = x1 + (int) ((x2 - x1 + 1) * f), bX = x2 - (int) ((x2 - x1 + 1) * f);
        int aZ = z1 + (int) ((z2 - z1 + 1) * f), bZ = z2 - (int) ((z2 - z1 + 1) * f);
        for (int px : new int[]{aX, bX}) { // северный и южный фасады
            if (doorOnZ && Math.abs(px - door[0]) <= 2) continue;
            pilaster(lv, s, fy, h, px, z1);
            pilaster(lv, s, fy, h, px, z2);
        }
        for (int pz : new int[]{aZ, bZ}) { // восточный и западный фасады
            if (doorOnX && Math.abs(pz - door[2]) <= 2) continue;
            pilaster(lv, s, fy, h, x1, pz);
            pilaster(lv, s, fy, h, x2, pz);
        }
    }

    /**
     * Антенна: три плоскости по три железных люка (пол и две стенки), каждая «Г» из 2x2 без
     * дальней клетки; вместе образуют угол куба, с любой стороны читается «Г» с тонкими кромками
     * двух других плоскостей. Всего 9 люков. Позиция и угол поворота сохраняются в LabSavedData:
     * позже антенну будет вращать терминал для загадки с замком.
     */
    private static void dish(ServerLevel lv, Style s, int fy, int h, int x1, int z1, int x2, int z2, int[] lift, LabSavedData d) {
        int size = 4; // плита-основание 4x4
        if (x2 - x1 < size + 2 || z2 - z1 < size + 2) return;
        int inset = LabTuning.ROOF_HATCH_INSET;
        int hx1 = x1 + inset, hz1 = z1 + inset, hx2 = x2 - inset, hz2 = z2 - inset;
        int midX = (x1 + x2) / 2, midZ = (z1 + z2) / 2;
        int bestX = Integer.MIN_VALUE, bestZ = 0, best = Integer.MIN_VALUE;
        for (int px = x1 + 1; px <= x2 - size; px++) {
            for (int pz = z1 + 1; pz <= z2 - size; pz++) {
                if (lift[0] >= 0 && overlaps(px, pz, size, lift[0], lift[2], 1)) continue; // машинное помещение
                if (overlaps(px, pz, size, hx1, hz1, 0) || overlaps(px, pz, size, hx2, hz2, 0)) continue; // люки
                int score = -(Math.abs(px + size / 2 - midX) + Math.abs(pz + size / 2 - midZ));
                if (score > best) {
                    best = score;
                    bestX = px;
                    bestZ = pz;
                }
            }
        }
        if (best == Integer.MIN_VALUE) return;
        int y = fy + h; // кровля
        // Основа 2x2 прямо на кровле: две ограды из каменного кирпича (2 блока) по одной диагонали
        // и два полированных андезита (1 блок) по другой. Тарелка лежит на оградах.
        // Тарелка: три плоскости по три люка (пол и две стенки), каждая «Г» из 2x2 без дальней клетки.
        // Мачта стоит в пустой клетке тарелки, прямо на её уровне.
        for (int a = 0; a < size; a++) // очистка зоны (на случай старой антенны при rebuild)
            for (int b = 0; b < size; b++)
                for (int k = 1; k <= 9; k++) set(lv, bestX + a, y + k, bestZ + b, AIR);
        int x0 = bestX + 1, z0 = bestZ + 1; // первая клетка пола
        int p = y + 3;                       // уровень тарелки: на верхушках оград
        BlockState fence = Blocks.STONE_BRICK_WALL.defaultBlockState();
        for (int k = 1; k <= 2; k++) {       // ограды: клетки (0,0) и (1,1)
            set(lv, x0, y + k, z0, fence);
            set(lv, x0 + 1, y + k, z0 + 1, fence);
        }
        set(lv, x0 + 1, y + 1, z0, s.floor2);  // андезит: клетки (1,0) и (0,1)
        set(lv, x0, y + 1, z0 + 1, s.floor2);
        BlockState flat = trapdoor(Direction.NORTH, false);  // закрытый, half=bottom
        BlockState wallN = trapdoor(Direction.NORTH, true);  // панель у южного края клетки, вплотную к полу [проверить]
        BlockState wallW = trapdoor(Direction.WEST, true);   // панель у восточного края клетки [проверить]
        set(lv, x0, p, z0, flat);                // пол
        set(lv, x0 + 1, p, z0, flat);
        set(lv, x0, p, z0 + 1, flat);
        set(lv, x0, p, z0 - 1, wallN);           // северная стенка (ряд z0-1)
        set(lv, x0 + 1, p, z0 - 1, wallN);
        set(lv, x0, p + 1, z0 - 1, wallN);
        set(lv, x0 - 1, p, z0, wallW);           // западная стенка (столбец x0-1)
        set(lv, x0 - 1, p, z0 + 1, wallW);
        set(lv, x0 - 1, p + 1, z0, wallW);
        for (int k = 0; k < 6; k++) set(lv, x0 + 1, p + k, z0 + 1, Blocks.IRON_BARS.defaultBlockState()); // мачта из тарелки
        set(lv, x0 + 1, p + 6, z0 + 1, rod(Direction.UP));  // холодный огонёк на конце
        d.dishPos = new BlockPos(bestX + 1, y + 1, bestZ + 1).asLong(); // задел под поворот через терминал
        d.dishAngle = 0;
    }

    /** Железный люк: open=true — вертикальная панель, open=false — горизонтальная. */
    private static BlockState trapdoor(Direction facing, boolean open) {
        return trapdoor(facing, open, Half.BOTTOM);
    }

    /** По умолчанию у люка half=top (первое значение enum), поэтому half задаём явно. */
    private static BlockState trapdoor(Direction facing, boolean open, Half half) {
        return Blocks.IRON_TRAPDOOR.defaultBlockState()
                .setValue(net.minecraft.world.level.block.TrapDoorBlock.OPEN, open)
                .setValue(net.minecraft.world.level.block.TrapDoorBlock.FACING, facing)
                .setValue(net.minecraft.world.level.block.TrapDoorBlock.HALF, half);
    }

    /** Полублок столбика ограды: тот же каменный кирпич, что и сама ограда. */
    private static final BlockState PARAPET_SLAB = Blocks.STONE_BRICK_SLAB.defaultBlockState();

    /** Столбик ставится на обоих углах и на каждом step-м блоке ограды. */
    private static boolean isPost(int i, int len, int step) {
        return i == 0 || i == len || i % step == 0;
    }

    /** Пересекается ли квадрат size x size в (x,z) с точкой (ox,oz) и запасом pad. */
    private static boolean overlaps(int x, int z, int size, int ox, int oz, int pad) {
        return ox >= x - pad && ox < x + size + pad && oz >= z - pad && oz < z + size + pad;
    }

    private static void pilaster(ServerLevel lv, Style s, int fy, int h, int x, int z) {
        for (int y = fy; y <= fy + h - 1; y++) set(lv, x, y, z, s.trim);
    }

    /**
     * Рельеф плоской крыши (никаких скатов): ограда из каменного кирпича по краю со столбиками
     * (блок + полублок сверху) на углах и с шагом, машинное помещение над кабиной лифта и два люка.
     * Плюс антенна (dish()).
     */
    private static void roofDetails(ServerLevel lv, Style s, int fy, int h, int x1, int z1, int x2, int z2, int[] lift) {
        int y = fy + h + 1; // первый ряд над кровлей: сама ограда
        int step = LabTuning.PARAPET_POST_EVERY;
        for (int x = x1; x <= x2; x++) { // ограда: один ряд каменного кирпича по периметру
            set(lv, x, y, z1, s.wall);
            set(lv, x, y, z2, s.wall);
            if (isPost(x - x1, x2 - x1, step)) {
                set(lv, x, y + 1, z1, PARAPET_SLAB);
                set(lv, x, y + 1, z2, PARAPET_SLAB);
            }
        }
        for (int z = z1 + 1; z < z2; z++) {
            set(lv, x1, y, z, s.wall);
            set(lv, x2, y, z, s.wall);
            if (isPost(z - z1, z2 - z1, step)) {
                set(lv, x1, y + 1, z, PARAPET_SLAB);
                set(lv, x2, y + 1, z, PARAPET_SLAB);
            }
        }

    }

    /**
     * Проход: '=' — 3 блока в ширину на 3 в высоту, 'l' — дверь лифта 1x3 (механизм остаётся одноколоночным).
     * Вокруг проёма — тёмная рамка: столбы по бокам и перемычка сверху. Рисуется после стен.
     */
    private static void passage(ServerLevel lv, Style s, LabBlueprint bp, int x, int z, int wx, int wz, int fy, int h, boolean widen) {
        boolean alongX = bp.at(x - 1, z) == '#' && bp.at(x + 1, z) == '#';
        int dx = alongX ? 1 : 0; // нет стен по бокам — считаем, что стена идёт вдоль Z
        int dz = alongX ? 0 : 1;
        int half = widen ? 1 : 0;     // половина ширины проёма
        int frame = half + 1;         // рамка сразу за проёмом
        for (int k = -frame; k <= frame; k++) {
            int px = wx + dx * k, pz = wz + dz * k;
            set(lv, px, fy - 1, pz, s.floor2); // тёмный порог
            if (Math.abs(k) <= half) {
                for (int y = 0; y < 3; y++) set(lv, px, fy + y, pz, AIR);
                for (int y = 3; y < h; y++) set(lv, px, fy + y, pz, s.trim); // перемычка
            } else {
                for (int y = 0; y < h; y++) set(lv, px, fy + y, pz, s.trim); // столб рамки
            }
        }
    }

    private static final Direction[] ORDER = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};

    /**
     * @param ox, oz мировые координаты клетки '@'
     * @param fy     y первого блока воздуха над полом
     * @param stop   номер остановки лифта (0 = поверхность)
     */
    public static void build(ServerLevel level, LabBlueprint bp, int ox, int oz, int fy, int stop, boolean surface, LabSavedData d) {
        Style s = style(bp.dream);
        int h = bp.height;
        int[] door = {-1, 0, 0}; // world x/y/z внешнего входа ('=')
        int[] lift = {-1, 0, 0}; // world x/y/z кабины лифта ('@')
        int minX = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE, maxX = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;
        if (surface) {
            int[] b = bounds(bp, ox, oz);
            terraform(level, s, fy, b[0], b[1], b[2], b[3], entrance(bp, ox, oz));
        }

        for (int z = 0; z < bp.d; z++) {
            for (int x = 0; x < bp.w; x++) {
                char c = bp.at(x, z);
                if (c == ' ') continue;
                int wx = ox + x - bp.ax, wz = oz + z - bp.az;
                minX = Math.min(minX, wx);
                maxX = Math.max(maxX, wx);
                minZ = Math.min(minZ, wz);
                maxZ = Math.max(maxZ, wz);
                column(level, s, c, wx, wz, fy, h);
                if (c == '@' && lift[0] < 0) {
                    lift[0] = wx;
                    lift[2] = wz;
                }
                if (surface && c == '=') {
                    door[0] = wx;
                    door[1] = fy;
                    door[2] = wz;
                    lampPosts(level, bp, s, x, z, wx, wz, fy);
                }
                if (c == 'l') d.door[stop] = new BlockPos(wx, fy, wz).asLong();
            }
        }

        // Таблички и интерактив (после стен: нужна опора).
        for (int z = 0; z < bp.d; z++) {
            for (int x = 0; x < bp.w; x++) {
                char c = bp.at(x, z);
                boolean digit = c >= '1' && c <= '9';
                if (!digit && c != 'E' && c != 'K' && c != 'J' && c != '=' && c != 'l') continue;
                int wx = ox + x - bp.ax, wz = oz + z - bp.az;
                if (c == '=' || c == 'l') { // проходы режем после стен, иначе соседние клетки закроют проём
                    passage(level, s, bp, x, z, wx, wz, fy, h, c == '=');
                    continue;
                }
                BlockPos pos = new BlockPos(wx, fy + 1, wz);
                Direction facing = facing(bp, x, z);
                if (digit) {
                    String[] t = bp.signs.get(c);
                    LabSigns.wall(level, pos, facing, t == null ? new String[0] : t);
                } else if (c == 'E') {
                    LabSigns.wall(level, pos, facing, "ELEVATOR", "LEVEL " + LabTuning.stopLabel(stop));
                    d.inter.put(pos.asLong(), LabSavedData.KIND_LIFT * 1000 + stop);
                } else {
                    Integer id = bp.locks.get(c);
                    if (id == null) continue;
                    LabSigns.wall(level, pos, facing, "ACCESS", "ENTER CODE", "", "[ LOCKED ]");
                    d.inter.put(pos.asLong(), LabSavedData.KIND_LOCK * 1000 + id);
                }
            }
        }

        if (surface) {
            facade(level, s, fy, h, minX, minZ, maxX, maxZ, door);
            roofDetails(level, s, fy, h, minX, minZ, maxX, maxZ, lift);
            dish(level, s, fy, h, minX, minZ, maxX, maxZ, lift, d);
        }

        d.stopY[stop] = fy;
        d.stopH[stop] = h;
        d.bbox[stop * 4] = minX;
        d.bbox[stop * 4 + 1] = minZ;
        d.bbox[stop * 4 + 2] = maxX;
        d.bbox[stop * 4 + 3] = maxZ;
        d.builtMask |= 1 << stop;
    }

    /** Лицевая сторона таблички: от первой найденной стены в комнату. */
    private static Direction facing(LabBlueprint bp, int x, int z) {
        for (Direction dir : ORDER)
            if (bp.at(x + dir.getStepX(), z + dir.getStepZ()) == '#') return dir.getOpposite();
        return Direction.SOUTH;
    }

    private static void set(ServerLevel level, int x, int y, int z, BlockState st) {
        level.setBlock(new BlockPos(x, y, z), st, 2);
    }

    private static void column(ServerLevel lv, Style s, char c, int x, int z, int fy, int h) {
        if (c == '#') {
            // Стена: тёмный цоколь (первый ряд), поле из камня с редкими трещинами; карниз и пилястры — через facade().
            for (int y = fy - 1; y < fy + h; y++)
                set(lv, x, y, z, y == fy ? s.trim : wallAt(s, x, y, z));
            set(lv, x, fy + h, z, s.roof);
            return;
        }
        boolean door = c == '=' || c == 'l';
        boolean cabin = c == 'L' || c == '@' || c == 'Y' || c == 'E';
        // Пол: клетка-шахматка из двух оттенков камня; кабина и проёмы — тёмная плита.
        set(lv, x, fy - 1, z, cabin || door ? s.floor2 : ((x ^ z) & 1) == 0 ? s.floor : s.floor2);
        int open = door ? 3 : h;
        for (int y = 0; y < h; y++) set(lv, x, fy + y, z, y >= open ? s.wall : AIR);
        set(lv, x, fy + h, z, s.roof);
        if (c == '*' || c == 'Y') set(lv, x, fy + h - 1, z, rod(Direction.DOWN));
        switch (c) {
            case 'T' -> set(lv, x, fy, z, Blocks.DARK_OAK_SLAB.defaultBlockState());
            case 'R' -> {
                set(lv, x, fy, z, Blocks.BOOKSHELF.defaultBlockState());
                set(lv, x, fy + 1, z, Blocks.BOOKSHELF.defaultBlockState());
            }
            case 'U' -> set(lv, x, fy, z, Blocks.BARREL.defaultBlockState());
            default -> { }
        }
    }

    /** Мировые границы (minX, minZ, maxX, maxZ) непустых клеток чертежа. */
    private static int[] bounds(LabBlueprint bp, int ox, int oz) {
        int x1 = Integer.MAX_VALUE, z1 = Integer.MAX_VALUE, x2 = Integer.MIN_VALUE, z2 = Integer.MIN_VALUE;
        for (int z = 0; z < bp.d; z++)
            for (int x = 0; x < bp.w; x++) {
                if (bp.at(x, z) == ' ') continue;
                int wx = ox + x - bp.ax, wz = oz + z - bp.az;
                x1 = Math.min(x1, wx);
                x2 = Math.max(x2, wx);
                z1 = Math.min(z1, wz);
                z2 = Math.max(z2, wz);
            }
        return new int[]{x1, z1, x2, z2};
    }

    /** Мировые координаты внешнего входа ('=') или null, если его нет. */
    private static int[] entrance(LabBlueprint bp, int ox, int oz) {
        for (int z = 0; z < bp.d; z++)
            for (int x = 0; x < bp.w; x++)
                if (bp.at(x, z) == '=') return new int[]{ox + x - bp.ax, oz + z - bp.az};
        return null;
    }

    /** Уровень пола павильона: верхний процентиль высот земли по площадке (здание + двор), не ниже уровня моря + 1. */
    public static int padLevel(ServerLevel level, LabBlueprint bp, int ox, int oz) {
        int[] b = bounds(bp, ox, oz);
        int y = LabTuning.YARD;
        int n = 0;
        int[] hs = new int[((b[2] - b[0] + 2 * y) / 2 + 2) * ((b[3] - b[1] + 2 * y) / 2 + 2)];
        for (int x = b[0] - y; x <= b[2] + y; x += 2)
            for (int z = b[1] - y; z <= b[3] + y; z += 2)
                hs[n++] = groundTop(level, x, z);
        Arrays.sort(hs, 0, n);
        int idx = Math.min(n - 1, (int) (n * LabTuning.PAD_PERCENTILE));
        return Math.max(hs[idx], level.getSeaLevel() + 1);
    }

    /** Высота настоящей земли: стволы, листва, растения и снег землёй не считаются. Возвращает первый свободный блок над землёй. */
    private static int groundTop(ServerLevel lv, int x, int z) {
        int y = lv.getHeight(Heightmap.Types.WORLD_SURFACE, x, z);
        while (y > lv.getMinBuildHeight()) {
            BlockState st = lv.getBlockState(new BlockPos(x, y - 1, z));
            boolean soft = st.isAir() || st.is(BlockTags.LOGS) || st.is(BlockTags.LEAVES)
                    || (st.canBeReplaced() && st.getFluidState().isEmpty()); // [проверить: canBeReplaced()]
            if (!soft) break;
            y--;
        }
        return y;
    }

    /**
     * Минимальная подготовка площадки: ровный мощёный двор YARD блоков вокруг здания, узкая
     * подпорная стенка в один блок по его краю и дорожка от входа. Широкого откоса нет — за стенкой
     * рельеф остаётся таким, каким его создал генератор, поэтому деревни и склоны не разваливаются.
     * Деревья, листва и вода под площадкой заменяются.
     */
    private static void terraform(ServerLevel lv, Style s, int fy, int x1, int z1, int x2, int z2, int[] door) {
        int yard = LabTuning.YARD;
        int px1 = x1 - yard, px2 = x2 + yard, pz1 = z1 - yard, pz2 = z2 + yard;
        for (int x = px1; x <= px2; x++) {
            for (int z = pz1; z <= pz2; z++) {
                int top = lv.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
                int topAll = lv.getHeight(Heightmap.Types.WORLD_SURFACE, x, z);
                // всё выше пола двора срезано (деревья, листва, рельеф)
                for (int y = fy; y <= Math.max(topAll, fy); y++) {
                    BlockPos p = new BlockPos(x, y, z);
                    if (!lv.getBlockState(p).isAir()) lv.setBlock(p, AIR, 2);
                }
                set(lv, x, fy - 1, z, s.floor2); // плита двора
                // подсыпка под плитой до первого твёрдого блока
                for (int y = fy - 2; y >= fy - 1 - LabTuning.FILL_DEPTH; y--) {
                    BlockPos p = new BlockPos(x, y, z);
                    BlockState st = lv.getBlockState(p);
                    if (st.isAir() || st.canBeReplaced() || !st.getFluidState().isEmpty()
                            || st.is(BlockTags.LOGS) || st.is(BlockTags.LEAVES)) lv.setBlock(p, s.wall, 2);
                    else break;
                }
            }
        }
        // направление наружу от входа: проём в подпорной стенке и дорожка к нему
        int outX = 0, outZ = 0;
        if (door != null) {
            if (door[1] == z2) outZ = 1;
            else if (door[1] == z1) outZ = -1;
            else if (door[0] == x2) outX = 1;
            else if (door[0] == x1) outX = -1;
        }
        // подпорная стенка по периметру двора: держит и срез, и подсыпку, но не трогает рельеф дальше
        for (int x = px1 - 1; x <= px2 + 1; x++) {
            for (int z = pz1 - 1; z <= pz2 + 1; z++) {
                boolean ring = x == px1 - 1 || x == px2 + 1 || z == pz1 - 1 || z == pz2 + 1;
                if (!ring) continue;
                boolean gap = door != null && (outX > 0 ? x == px2 + 1 && Math.abs(z - door[1]) <= 1
                        : outX < 0 ? x == px1 - 1 && Math.abs(z - door[1]) <= 1
                        : outZ > 0 ? z == pz2 + 1 && Math.abs(x - door[0]) <= 1
                        : outZ < 0 && z == pz1 - 1 && Math.abs(x - door[0]) <= 1);
                if (gap) continue; // место под входную дорожку
                int top = groundTop(lv, x, z);
                int topAll = lv.getHeight(Heightmap.Types.WORLD_SURFACE, x, z);
                int low = Math.min(fy - 1, top - 1);
                int wallTop = Math.min(Math.max(fy - 1, top - 1), fy + LabTuning.WALL_MAX_ABOVE);
                for (int y = low; y <= wallTop; y++) set(lv, x, y, z, s.trim);
                for (int y = wallTop + 1; y <= topAll; y++) { // срезаем деревья над стенкой
                    BlockPos p = new BlockPos(x, y, z);
                    if (!lv.getBlockState(p).isAir()) lv.setBlock(p, AIR, 2);
                }
            }
        }
        if (door == null || outX == 0 && outZ == 0) return;
        // дорожка от входа: 3 блока в ширину, по 1 блоку подъёма/спуска за шаг, потом упирается в рельеф
        int first = yard + 1; // первая клетка за двором — та самая прореха в подпорной стенке
        for (int k = first; k < first + LabTuning.ENTRY_PATH; k++) {
            for (int side = -1; side <= 1; side++) {
                int x = door[0] + outX * k + (outX == 0 ? side : 0);
                int z = door[1] + outZ * k + (outZ == 0 ? side : 0);
                int top = groundTop(lv, x, z);
                int topAll = lv.getHeight(Heightmap.Types.WORLD_SURFACE, x, z);
                int natural = top - 1;
                int step = k - first;
                int target = Math.max(fy - 1 - step, Math.min(fy - 1 + step, natural));
                for (int y = target + 1; y <= Math.max(topAll, target); y++) {
                    BlockPos p = new BlockPos(x, y, z);
                    if (!lv.getBlockState(p).isAir()) lv.setBlock(p, AIR, 2);
                }
                set(lv, x, target, z, s.floor2);
                for (int y = target - 1; y >= target - LabTuning.FILL_DEPTH; y--) {
                    BlockPos p = new BlockPos(x, y, z);
                    BlockState st = lv.getBlockState(p);
                    if (st.isAir() || st.canBeReplaced() || !st.getFluidState().isEmpty()
                            || st.is(BlockTags.LOGS) || st.is(BlockTags.LEAVES)) lv.setBlock(p, s.wall, 2);
                    else break;
                }
            }
        }
    }

    /** Два фонаря по сторонам наружного проёма: бетонный столб и лампа сверху. */
    private static void lampPosts(ServerLevel lv, LabBlueprint bp, Style s, int x, int z, int wx, int wz, int fy) {
        for (Direction out : ORDER) {
            if (bp.at(x + out.getStepX(), z + out.getStepZ()) != ' ') continue;
            Direction side = out.getClockWise();
            for (int k = -2; k <= 2; k += 4) {
                int px = wx + out.getStepX() * 2 + side.getStepX() * k;
                int pz = wz + out.getStepZ() * 2 + side.getStepZ() * k;
                set(lv, px, fy, pz, s.trim); // серое основание фонаря
                for (int y = 1; y < 3; y++) set(lv, px, fy + y, pz, s.wall);
                set(lv, px, fy + 3, pz, rod(Direction.UP));
            }
            return;
        }
    }

    /** Стирает постройку остановки (кроме фундамента): воздух от пола до потолка в её прямоугольнике. */
    public static void clear(ServerLevel level, LabSavedData d, int stop) {
        if (!d.isBuilt(stop)) return;
        int fy = d.stopY[stop], h = d.stopH[stop];
        int x1 = d.bbox[stop * 4], z1 = d.bbox[stop * 4 + 1], x2 = d.bbox[stop * 4 + 2], z2 = d.bbox[stop * 4 + 3];
        if (stop == 0) { // фонари у входа стоят за границей чертежа — стираем вместе с ними
            x1 -= 2;
            z1 -= 2;
            x2 += 2;
            z2 += 2;
        }
        // Пол поверхности (fy-1) оставляем: площадка не должна проседать при пересборке.
        int y0 = stop == 0 ? fy : fy - 1;
        int top = stop == 0 ? fy + h + LabTuning.ROOF_CLEAR : fy + h + 1; // поверхность: ещё парапет, будка и тарелка
        for (int x = x1; x <= x2; x++)
            for (int z = z1; z <= z2; z++)
                for (int y = y0; y <= top; y++) set(level, x, y, z, AIR);
    }
}
