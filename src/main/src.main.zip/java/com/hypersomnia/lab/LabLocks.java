package com.hypersomnia.lab;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;

import java.util.Map;

/** Замки лаборатории: проверка ответа, последствия открытия, тексты табличек. */
public final class LabLocks {
    private LabLocks() {}

    public static boolean check(LabSavedData d, int id, int code) {
        return code == LabTuning.lockCode(id, d.dream);
    }

    public static void grant(ServerLevel level, LabSavedData d, int id) {
        if (d.isLockOpen(id)) return;
        d.locksOpen |= 1 << id;
        if (id == LabTuning.LOCK_HATCH) d.reached = Math.max(d.reached, 1);
        LabLift.refreshDoors(level, d);
        refreshSigns(level, d);
        BlockPos p = d.lockPos(id);
        if (p != null) level.playSound(null, p, SoundEvents.IRON_DOOR_OPEN, SoundSource.BLOCKS, 1.0f, 0.55f);
        d.setDirty();
    }

    public static void refreshSigns(ServerLevel level, LabSavedData d) {
        for (Map.Entry<Long, Integer> e : d.inter.entrySet()) {
            int v = e.getValue();
            if (v / 1000 != LabSavedData.KIND_LOCK) continue;
            boolean open = d.isLockOpen(v % 1000);
            LabSigns.update(level, BlockPos.of(e.getKey()), "ACCESS", open ? "GRANTED" : "ENTER CODE", "",
                    open ? "[ OPEN ]" : "[ LOCKED ]");
        }
    }
}
