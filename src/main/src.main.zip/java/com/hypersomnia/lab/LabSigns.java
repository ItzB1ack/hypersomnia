package com.hypersomnia.lab;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.WallSignBlock;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.entity.SignText;

/** Настенные таблички лаборатории: белый светящийся текст, заблокированы от правки. */
public final class LabSigns {
    private LabSigns() {}

    public static void wall(ServerLevel level, BlockPos pos, Direction facing, String... lines) {
        level.setBlock(pos, Blocks.DARK_OAK_WALL_SIGN.defaultBlockState().setValue(WallSignBlock.FACING, facing), 2);
        if (level.getBlockEntity(pos) instanceof SignBlockEntity sign) {
            SignText text = new SignText().setColor(DyeColor.WHITE).setHasGlowingText(true);
            for (int i = 0; i < lines.length && i < 4; i++) text = text.setMessage(i, Component.literal(lines[i]));
            sign.setText(text, true);
            sign.setWaxed(true);
            sign.setChanged();
            level.sendBlockUpdated(pos, level.getBlockState(pos), level.getBlockState(pos), 3);
        }
    }

    /** Меняет текст уже стоящей таблички. */
    public static void update(ServerLevel level, BlockPos pos, String... lines) {
        if (level.getBlockEntity(pos) instanceof SignBlockEntity sign) {
            SignText text = sign.getText(true);
            for (int i = 0; i < 4; i++) text = text.setMessage(i, Component.literal(i < lines.length ? lines[i] : ""));
            sign.setText(text, true);
            sign.setChanged();
            level.sendBlockUpdated(pos, level.getBlockState(pos), level.getBlockState(pos), 3);
        }
    }
}
