package com.hypersomnia.trace;

/** Числа детских следов. Общий код, без клиентских импортов. */
public final class TraceTuning {
    private TraceTuning() {}

    /** С какой стадии осколка появляются следы после сна. */
    public static final int MIN_STAGE = 3;
    /** Шанс, что после пробуждения появятся новые следы. */
    public static final float WAKE_CHANCE = 0.7f;
    public static final int PER_WAKE_MIN = 1;
    public static final int PER_WAKE_MAX = 3;
    /** Всего следов у игрока; при переполнении самые старые убираются. */
    public static final int MAX_TOTAL = 24;
    /** Радиус поиска места вокруг кровати (блоки) и число попыток на один след. Первую половину попыток только в помещении. */
    public static final int RADIUS = 12;
    public static final int ATTEMPTS = 24;
    /** Клиент: дальше этой дистанции не рисуем; отступ «наклейки» от поверхности, чтобы не мерцала. */
    public static final double RENDER_DISTANCE = 48.0;
    public static final float DECAL_OFFSET = 0.015f;
}