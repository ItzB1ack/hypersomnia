package com.hypersomnia.network;

import com.hypersomnia.Hypersomnia;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Сервер -> клиент: прогресс, из которого клиент считает стадию осколка. */
public record ObserverStagePayload(int days, int memories) implements CustomPacketPayload {

    public static final Type<ObserverStagePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(Hypersomnia.MOD_ID, "observer_stage"));

    public static final StreamCodec<ByteBuf, ObserverStagePayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.INT, ObserverStagePayload::days,
            ByteBufCodecs.INT, ObserverStagePayload::memories,
            ObserverStagePayload::new
    );

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}