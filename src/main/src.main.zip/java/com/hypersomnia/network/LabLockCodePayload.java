package com.hypersomnia.network;

import com.hypersomnia.Hypersomnia;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Клиент -> сервер: введённый код замка lock (0-9999). */
public record LabLockCodePayload(int lock, int code) implements CustomPacketPayload {

    public static final Type<LabLockCodePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(Hypersomnia.MOD_ID, "lab_lock_code"));

    public static final StreamCodec<ByteBuf, LabLockCodePayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.INT, LabLockCodePayload::lock,
            ByteBufCodecs.INT, LabLockCodePayload::code,
            LabLockCodePayload::new
    );

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
