package com.hypersomnia.network;

import com.hypersomnia.Hypersomnia;
import com.hypersomnia.client.ObserverState;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

/** Регистрация пакета наблюдателя отдельно от Hypersomnia.java, чтобы не трогать основной класс. */
@EventBusSubscriber(modid = Hypersomnia.MOD_ID, bus = EventBusSubscriber.Bus.MOD)
public final class ObserverNetwork {
    private ObserverNetwork() {}

    @SubscribeEvent
    public static void registerPayloads(RegisterPayloadHandlersEvent event) {
        var registrar = event.registrar("1");
        registrar.playToClient(
                MadnessSyncPayload.TYPE,
                MadnessSyncPayload.STREAM_CODEC,
                ObserverState::handleMadness
        );
        registrar.playToClient(
                ObserverStagePayload.TYPE,
                ObserverStagePayload.STREAM_CODEC,
                ObserverState::handleStage
        );
    }
}
