package com.hypersomnia.network;

import com.hypersomnia.Hypersomnia;
import com.hypersomnia.client.LabClientState;
import com.hypersomnia.server.LabHandler;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;

@EventBusSubscriber(modid = Hypersomnia.MOD_ID, bus = EventBusSubscriber.Bus.MOD)
public final class LabNetwork {
    private LabNetwork() {}

    @SubscribeEvent
    public static void registerPayloads(RegisterPayloadHandlersEvent event) {
        var registrar = event.registrar("1");
        registrar.playToClient(LabLockPayload.TYPE, LabLockPayload.STREAM_CODEC, LabClientState::handleLock);
        registrar.playToServer(LabLockCodePayload.TYPE, LabLockCodePayload.STREAM_CODEC, LabHandler::handleLockCode);
        registrar.playToClient(LabLiftPayload.TYPE, LabLiftPayload.STREAM_CODEC, LabClientState::handleLift);
        registrar.playToServer(LabLiftSelectPayload.TYPE, LabLiftSelectPayload.STREAM_CODEC, LabHandler::handleLiftSelect);
    }
}
