package com.hypersomnia.network;

import com.hypersomnia.Hypersomnia;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Сервер -> клиент: открыть кодовую панель замка (OPEN) или результат проверки. */
public record LabLockPayload(int lock, int state) implements CustomPacketPayload {
    public static final int OPEN = -1;
    public static final int DENIED = 0;
    public static final int GRANTED = 1;

    public static final Type<LabLockPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(Hypersomnia.MOD_ID, "lab_lock"));

    public static final StreamCodec<ByteBuf, LabLockPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.INT, LabLockPayload::lock,
            ByteBufCodecs.INT, LabLockPayload::state,
            LabLockPayload::new
    );

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
