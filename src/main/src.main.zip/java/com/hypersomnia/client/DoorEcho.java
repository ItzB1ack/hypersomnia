package com.hypersomnia.client;

import com.hypersomnia.Hypersomnia;
import com.hypersomnia.ObserverTuning;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/**
 * Стадия 4: где-то за спиной в доме дверь «открывается и закрывается» несколько раз подряд.
 * Только звук на клиенте, дверь в мире не меняется. Дверь выбирается вне поля зрения.
 */
@EventBusSubscriber(modid = Hypersomnia.MOD_ID, value = Dist.CLIENT)
public final class DoorEcho {
    private DoorEcho() {}

    private static int cooldown = ObserverTuning.DOOR_CHECK_TICKS;
    private static int cyclesLeft;
    private static int wait;
    private static boolean open;
    private static Vec3 at = Vec3.ZERO;

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        LocalPlayer player = mc.player;
        if (level == null || player == null || mc.isPaused()) return;
        if (level.dimension() != Level.OVERWORLD || player.isSleeping() || !player.isAlive() || SleepSceneState.active()) {
            cyclesLeft = 0;
            ObserverDirector.end(ObserverDirector.Kind.DOOR);
            return;
        }
        RandomSource r = level.random;

        if (cyclesLeft > 0) {
            if (watched(level, player)) {
                cyclesLeft = 0;
                ObserverDirector.end(ObserverDirector.Kind.DOOR);
                open = false;
                return;
            }
            if (--wait > 0) return;
            if (!open) {
                level.playLocalSound(at.x, at.y, at.z, SoundEvents.WOODEN_DOOR_OPEN, SoundSource.BLOCKS,
                        ObserverTuning.DOOR_VOLUME, 0.9f + r.nextFloat() * 0.2f, false);
                open = true;
                wait = range(r, ObserverTuning.DOOR_OPEN_GAP_MIN, ObserverTuning.DOOR_OPEN_GAP_MAX);
            } else {
                level.playLocalSound(at.x, at.y, at.z, SoundEvents.WOODEN_DOOR_CLOSE, SoundSource.BLOCKS,
                        ObserverTuning.DOOR_VOLUME, 0.9f + r.nextFloat() * 0.2f, false);
                open = false;
                if (--cyclesLeft == 0) ObserverDirector.end(ObserverDirector.Kind.DOOR);
                wait = range(r, ObserverTuning.DOOR_CLOSE_GAP_MIN, ObserverTuning.DOOR_CLOSE_GAP_MAX);
            }
            return;
        }

        if (ObserverState.stage() < ObserverTuning.DOOR_MIN_STAGE) return;
        if (--cooldown > 0) return;
        cooldown = ObserverTuning.DOOR_CHECK_TICKS;
        if (r.nextFloat() >= ObserverTuning.DOOR_CHANCE) return;
        // ночью или под крышей: днём на открытом месте дверь не хлопает
        if (!level.isNight() && level.canSeeSky(player.blockPosition().above())) return;

        BlockPos door = findDoor(level, player, r);
        if (door == null) return;
        if (!ObserverDirector.begin(ObserverDirector.Kind.DOOR)) return;
        at = Vec3.atCenterOf(door);
        cyclesLeft = range(r, ObserverTuning.DOOR_CYCLES_MIN, ObserverTuning.DOOR_CYCLES_MAX);
        open = false;
        wait = 1;
    }
    /** Игрок смотрит на дверь: она в конусе взгляда и между глазами и дверью нет блоков. */
    private static boolean watched(ClientLevel level, LocalPlayer player) {
        Vec3 eye = player.getEyePosition();
        Vec3 to = at.subtract(eye);
        double len = to.length();
        if (len < 0.5) return true;
        if (to.scale(1.0 / len).dot(player.getLookAngle()) < ObserverTuning.DOOR_STOP_LOOK_DOT) return false;
        BlockPos door = BlockPos.containing(at);
        HitResult hit = level.clip(new ClipContext(eye, at, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        if (hit.getType() == HitResult.Type.MISS) return true;
        BlockPos hp = ((BlockHitResult) hit).getBlockPos();
        return hp.equals(door) || hp.equals(door.above());
    }

    private static int range(RandomSource r, int min, int max) {
        return min + r.nextInt(max - min + 1);
    }

    /** Случайная дверь в радиусе, не ближе MIN_DIST и не в передней полусфере взгляда. */
    private static BlockPos findDoor(ClientLevel level, LocalPlayer player, RandomSource r) {
        BlockPos c = player.blockPosition();
        Vec3 look = player.getLookAngle();
        int rad = ObserverTuning.DOOR_RADIUS;
        double minSq = ObserverTuning.DOOR_MIN_DIST * ObserverTuning.DOOR_MIN_DIST;
        BlockPos best = null;
        int seen = 0;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int dx = -rad; dx <= rad; dx++) {
            for (int dz = -rad; dz <= rad; dz++) {
                for (int dy = -3; dy <= 3; dy++) {
                    p.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
                    if (!level.hasChunkAt(p)) continue;
                    BlockState s = level.getBlockState(p);
                    if (!s.is(BlockTags.WOODEN_DOORS) || s.getValue(DoorBlock.HALF) != DoubleBlockHalf.LOWER) continue;
                    double distSq = dx * dx + dy * dy + dz * dz;
                    if (distSq < minSq) continue;
                    double dot = (dx * look.x + dy * look.y + dz * look.z) / Math.sqrt(distSq);
                    if (dot > ObserverTuning.DOOR_MAX_LOOK_DOT) continue;
                    seen++;
                    if (r.nextInt(seen) == 0) best = p.immutable();   // равномерный выбор среди подходящих
                }
            }
        }
        return best;
    }
}