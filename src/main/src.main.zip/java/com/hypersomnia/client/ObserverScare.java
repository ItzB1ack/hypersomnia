package com.hypersomnia.client;

import com.hypersomnia.ObserverTuning;

import java.util.Random;

/**
 * Кадр-сюрприз осколка в мире снов. Пока только крючок: состояние и выбор строки, без отрисовки и звука.
 * Без клиентских импортов Minecraft. Ключи lang: hypersomnia.observer.scare.0-2 (запасной текст ниже).
 */
public final class ObserverScare {
    private ObserverScare() {}

    public static final String[] LINES = {"What am I?", "Is this my fault?", "Why can't I sleep?"};
    private static final Random RANDOM = new Random();

    /** Сколько тиков кадр ещё должен показываться (0 = не идёт). */
    public static int ticks;
    public static int line;
    public static int stage;
    private static int cooldown;

    public static boolean active() { return ticks > 0; }

    public static void trigger(int stageNow) {
        if (ticks > 0 || cooldown > 0) return;
        ticks = ObserverTuning.SCARE_TICKS;
        cooldown = ObserverTuning.SCARE_COOLDOWN_TICKS;
        line = RANDOM.nextInt(LINES.length);
        stage = stageNow;
        // TODO: отрисовка кадра (глаз крупно + строка) и решение по звуку
    }

    public static void tick() {
        if (ticks > 0) ticks--;
        if (cooldown > 0) cooldown--;
    }

    public static void reset() {
        ticks = 0;
        cooldown = 0;
    }
}