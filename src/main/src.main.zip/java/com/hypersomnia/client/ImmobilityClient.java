package com.hypersomnia.client;

import com.hypersomnia.Hypersomnia;
import com.hypersomnia.ObserverTuning;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.sound.PlaySoundEvent;

/**
 * Неподвижность: 20 секунд без ввода -> тишина, один шаг за спиной, силуэт на периферии.
 * Любое движение/взгляд/клик/скролл сбрасывают счётчик. Спавн идёт через ObserverClient
 * (тот же призрак, но у края поля зрения и не исчезает по взгляду STILL_VISIBLE_TICKS).
 */
@EventBusSubscriber(modid = Hypersomnia.MOD_ID, value = Dist.CLIENT)
public final class ImmobilityClient {
    private ImmobilityClient() {}

    private static int stillTicks;
    private static int cooldown;
    private static int silenceTicks;
    private static int spawnDelay = -1;
    private static float lastYaw;
    private static float lastPitch;
    private static boolean hadPlayer;

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null || mc.isPaused()) {
            stillTicks = 0;
            hadPlayer = false;
            return;
        }

        if (silenceTicks > 0) {
            silenceTicks--;
            if (silenceTicks == 0) {
                playStepBehind(mc, player);
                spawnDelay = ObserverTuning.STILL_SPAWN_DELAY;
            }
            return;
        }
        if (spawnDelay > 0) {
            if (--spawnDelay == 0) {
                ObserverClient.tryPeripherySpawn();
                spawnDelay = -1;
                cooldown = ObserverTuning.STILL_COOLDOWN;
            }
            return;
        }

        if (cooldown > 0) cooldown--;

        float yaw = player.getYRot();
        float pitch = player.getXRot();
        boolean turned = hadPlayer
                && (Math.abs(yaw - lastYaw) > 0.05f || Math.abs(pitch - lastPitch) > 0.05f);
        lastYaw = yaw;
        lastPitch = pitch;
        hadPlayer = true;

        boolean moving = player.getDeltaMovement().horizontalDistanceSqr() > 1.0E-4;
        if (moving || turned) {
            stillTicks = 0;
        } else if (stillTicks < Integer.MAX_VALUE) {
            stillTicks++;
        }

        if (stillTicks >= ObserverTuning.STILL_TICKS
                && cooldown == 0
                && !ObserverClient.hasGhost()
                && !isBusy(mc, player)) {
            stillTicks = 0;
            ObserverClient.deferSpawn = true;
            silenceTicks = ObserverTuning.STILL_SILENCE_TICKS;
            mc.getSoundManager().stop();
        }
    }

    private static boolean isBusy(Minecraft mc, LocalPlayer player) {
        if (player.isSleeping()) return true;
        if (mc.screen != null) return true;
        if (SleepSceneState.active()) return true;
        if (ClientFatigueState.collapsing) return true;
        return player.isCreative() || player.isSpectator() || !player.isAlive();
    }

    /** Один шаг за спиной, звук берётся у блока под ногами. */
    private static void playStepBehind(Minecraft mc, LocalPlayer player) {
        var look = player.getLookAngle();
        double dx = -look.x;
        double dz = -look.z;
        double len = Math.hypot(dx, dz);
        if (len > 1.0E-4) {
            dx /= len;
            dz /= len;
        }
        double dist = 2.0;
        double x = player.getX() + dx * dist;
        double y = player.getY();
        double z = player.getZ() + dz * dist;
        BlockState below = mc.level.getBlockState(player.blockPosition().below());
        SoundType type = below.getSoundType();
        if (type == null) return;
        mc.level.playLocalSound(x, y, z, type.getStepSound(), SoundSource.PLAYERS, 0.7f, 0.85f, false);
    }

    @SubscribeEvent
    public static void onInteraction(InputEvent.InteractionKeyMappingTriggered event) {
        stillTicks = 0;
    }

    @SubscribeEvent
    public static void onMouse(InputEvent.MouseButton.Pre event) {
        stillTicks = 0;
    }

    @SubscribeEvent
    public static void onScroll(InputEvent.MouseScrollingEvent event) {
        stillTicks = 0;
    }

    /** Тишина: глушим всё новое, что пытается заиграть, пока silenceTicks > 0. */
    @SubscribeEvent
    public static void onPlaySound(PlaySoundEvent event) {
        if (silenceTicks > 0) event.setSound(null);
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        stillTicks = 0;
        cooldown = 0;
        silenceTicks = 0;
        spawnDelay = -1;
        hadPlayer = false;
    }

    /** Отладка: запустить эпизод немедленно. Возвращает false, если уже идёт другой эпизод. */
    public static boolean triggerNow() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.isPaused()) return false;
        if (silenceTicks > 0 || spawnDelay > 0) return false;
        stillTicks = 0;
        ObserverClient.deferSpawn = true;
        silenceTicks = ObserverTuning.STILL_SILENCE_TICKS;
        mc.getSoundManager().stop();
        return true;
    }

    /** Отладка: сбросить счётчик, кулдаун и текущий эпизод. */
    public static void resetAll() {
        stillTicks = 0;
        cooldown = 0;
        silenceTicks = 0;
        spawnDelay = -1;
    }
}