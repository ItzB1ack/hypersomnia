package com.hypersomnia.client;

import com.hypersomnia.network.LabLiftPayload;
import com.hypersomnia.network.LabLockPayload;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Обработчики пакетов лаборатории на клиенте. Без клиентских импортов Minecraft (безопасно на сервере). */
public final class LabClientState {
    private LabClientState() {}

    public static void handleLock(LabLockPayload pl, IPayloadContext ctx) {
        ctx.enqueueWork(() -> LabLockScreen.receive(pl.lock(), pl.state()));
    }

    public static void handleLift(LabLiftPayload pl, IPayloadContext ctx) {
        ctx.enqueueWork(() -> LabLiftScreen.receive(pl.current(), pl.enabled(), pl.built()));
    }
}
