package com.hypersomnia.client;

import com.hypersomnia.lab.LabTuning;
import com.hypersomnia.network.LabLockCodePayload;
import com.hypersomnia.network.LabLockPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

/** Кодовая панель замка в аналоговом стиле. */
public final class LabLockScreen extends Screen {
    private static final int PW = 116, PH = 164, BW = 30, BH = 20, GAP = 4;
    private static final String[] KEYS = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "C", "0", "<"};
    private static final int VEIL = 0xD003050A;
    private static final int FRAME = 0xFF1E2A34;
    private static final int BODY = 0xFF0A0E12;
    private static final int GLASS = 0xFF05080B;
    private static final int TEXT = 0xFFDDE6EC;
    private static final int COLD = 0xFF4A5E70;
    private static final int RED = 0xFF8A2030;

    private enum Mode { INPUT, WAIT, DENIED, GRANTED }

    private final int lock;
    private final StringBuilder input = new StringBuilder();
    private Mode mode = Mode.INPUT;
    private int timer;

    private LabLockScreen(int lock) {
        super(Component.translatableWithFallback("hypersomnia.lab.lock." + lock, "CRADLE / ACCESS"));
        this.lock = lock;
    }

    /** Вызывать только на клиенте. */
    public static void receive(int lock, int state) {
        Minecraft mc = Minecraft.getInstance();
        if (state == LabLockPayload.OPEN) {
            mc.setScreen(new LabLockScreen(lock));
        } else if (mc.screen instanceof LabLockScreen s && s.lock == lock) {
            s.result(state == LabLockPayload.GRANTED);
        }
    }

    private void result(boolean ok) {
        mode = ok ? Mode.GRANTED : Mode.DENIED;
        timer = ok ? LabTuning.KEYPAD_GRANTED_TICKS : LabTuning.KEYPAD_DENIED_TICKS;
    }

    @Override
    public boolean isPauseScreen() { return false; }

    @Override
    public void tick() {
        if (timer > 0 && --timer == 0) {
            if (mode == Mode.GRANTED) {
                onClose();
            } else if (mode == Mode.DENIED) {
                input.setLength(0);
                mode = Mode.INPUT;
            }
        }
    }

    private int px() { return (width - PW) / 2; }
    private int py() { return (height - PH) / 2; }
    private int keyX(int c) { return px() + (PW - (3 * BW + 2 * GAP)) / 2 + c * (BW + GAP); }
    private int keyY(int r) { return py() + 62 + r * (BH + GAP); }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float pt) {
        g.fill(0, 0, width, height, VEIL);
        int x = px(), y = py();
        g.fill(x - 1, y - 1, x + PW + 1, y + PH + 1, FRAME);
        g.fill(x, y, x + PW, y + PH, BODY);
        g.drawCenteredString(font, title, x + PW / 2, y + 8, COLD);

        int dx = x + 10, dy = y + 26, dw = PW - 20, dh = 26;
        g.fill(dx, dy, dx + dw, dy + dh, GLASS);
        String shown;
        int color = TEXT;
        if (mode == Mode.DENIED) {
            shown = Component.translatable("hypersomnia.lab.lock.denied").getString();
            color = RED;
        } else if (mode == Mode.GRANTED) {
            shown = Component.translatable("hypersomnia.lab.lock.granted").getString();
        } else {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < LabTuning.CODE_DIGITS; i++) sb.append(i < input.length() ? input.charAt(i) : '_').append(' ');
            shown = sb.toString().trim();
        }
        int jitter = mode == Mode.DENIED && (timer / 2) % 2 == 0 ? 1 : 0;
        g.drawCenteredString(font, shown, dx + dw / 2 + jitter, dy + 9, color);
        for (int ly = dy; ly < dy + dh; ly += 2) g.fill(dx, ly, dx + dw, ly + 1, 0x18000000);

        for (int i = 0; i < KEYS.length; i++) {
            int bx = keyX(i % 3), by = keyY(i / 3);
            boolean hot = mode == Mode.INPUT && mouseX >= bx && mouseX < bx + BW && mouseY >= by && mouseY < by + BH;
            g.fill(bx - 1, by - 1, bx + BW + 1, by + BH + 1, FRAME);
            g.fill(bx, by, bx + BW, by + BH, hot ? 0xFF1E2A34 : GLASS);
            g.drawCenteredString(font, KEYS[i], bx + BW / 2, by + 6, hot ? TEXT : COLD);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && mode == Mode.INPUT) {
            for (int i = 0; i < KEYS.length; i++) {
                int bx = keyX(i % 3), by = keyY(i / 3);
                if (mx >= bx && mx < bx + BW && my >= by && my < by + BH) {
                    press(KEYS[i]);
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean charTyped(char c, int mods) {
        if (mode == Mode.INPUT && c >= '0' && c <= '9') {
            press(String.valueOf(c));
            return true;
        }
        return super.charTyped(c, mods);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (mode == Mode.INPUT && key == 259) { // Backspace
            press("<");
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    private void press(String k) {
        if (k.equals("C")) {
            input.setLength(0);
        } else if (k.equals("<")) {
            if (input.length() > 0) input.setLength(input.length() - 1);
        } else if (input.length() < LabTuning.CODE_DIGITS) {
            input.append(k);
            if (input.length() == LabTuning.CODE_DIGITS) {
                mode = Mode.WAIT;
                PacketDistributor.sendToServer(new LabLockCodePayload(lock, Integer.parseInt(input.toString())));
            }
        }
    }
}
