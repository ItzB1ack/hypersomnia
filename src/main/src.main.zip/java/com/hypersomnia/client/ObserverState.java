package com.hypersomnia.client;

import com.hypersomnia.network.MadnessSyncPayload;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Данные для наблюдателя на клиенте. Без клиентских импортов, как ClientFatigueState (безопасно на сервере). */
public final class ObserverState {
    private ObserverState() {}

    public static int madness;
    public static int days;
    public static int memories;

    /** Стадия осколка 0-5: от прожитых дней и найденных воспоминаний. Madness остаётся множителем частоты. */
    public static int stage() {
        return com.hypersomnia.ObserverTuning.stage(days, Integer.bitCount(memories));
    }

    public static void handleStage(com.hypersomnia.network.ObserverStagePayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            days = payload.days();
            memories = payload.memories();
        });
    }

    public static void handleMadness(MadnessSyncPayload payload, IPayloadContext ctx) {
        ctx.enqueueWork(() -> madness = payload.madness());
    }

    public static void reset() {
        madness = 0;
        days = 0;
        memories = 0;
        ObserverScare.reset();
        ObserverDirector.reset();
    }
}
