package com.hypersomnia.client;

import com.hypersomnia.Hypersomnia;
import com.hypersomnia.ObserverTuning;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.sound.PlaySoundEvent;

/**
 * Сбой экспозиции: редко, коротко, без тряски камеры. На время сбоя звук глушится.
 * Только клиент, никакой серверной логики.
 */
@EventBusSubscriber(modid = Hypersomnia.MOD_ID, value = Dist.CLIENT)
public final class GlitchClient {
    private GlitchClient() {}

    private static int cooldown = ObserverTuning.GLITCH_COOLDOWN_MIN;

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null || mc.isPaused()) {
            GlitchState.activeTicks = 0;
            GlitchState.totalTicks = 0;
            return;
        }
        if (GlitchState.activeTicks > 0) {
            GlitchState.activeTicks--;
            if (GlitchState.activeTicks == 0) {
                cooldown = Mth.randomBetweenInclusive(GlitchState.RANDOM,
                        ObserverTuning.GLITCH_COOLDOWN_MIN, ObserverTuning.GLITCH_COOLDOWN_MAX);
            }
            return;
        }
        if (--cooldown > 0) return;

        if (!isEligible(mc, player)) {
            cooldown = 200; // проверим снова через 10 с
            return;
        }
        int dur = Mth.randomBetweenInclusive(GlitchState.RANDOM,
                ObserverTuning.GLITCH_TICKS_MIN, ObserverTuning.GLITCH_TICKS_MAX);
        GlitchState.activeTicks = dur;
        GlitchState.totalTicks = dur;
        GlitchState.lineIndex = GlitchState.RANDOM.nextInt(3);
        mc.getSoundManager().stop();
    }

    private static boolean isEligible(Minecraft mc, LocalPlayer player) {
        if (player.isSleeping() || mc.screen != null) return false;
        if (SleepSceneState.active() || SleepSceneState.silent()) return false;
        if (ClientFatigueState.collapsing) return false;
        if (ObserverState.stage() < ObserverTuning.GLITCH_MIN_STAGE) return false;
        return true;
    }

    @SubscribeEvent
    public static void onPlaySound(PlaySoundEvent event) {
        if (GlitchState.activeTicks > 0) event.setSound(null);
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        GlitchState.activeTicks = 0;
        GlitchState.totalTicks = 0;
        cooldown = ObserverTuning.GLITCH_COOLDOWN_MIN;
    }

    /** Отладка: запустить сбой немедленно. */
    public static void triggerNow() {
        if (GlitchState.activeTicks > 0) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        int dur = Mth.randomBetweenInclusive(GlitchState.RANDOM,
                ObserverTuning.GLITCH_TICKS_MIN, ObserverTuning.GLITCH_TICKS_MAX);
        GlitchState.activeTicks = dur;
        GlitchState.totalTicks = dur;
        GlitchState.lineIndex = GlitchState.RANDOM.nextInt(3);
        mc.getSoundManager().stop();
    }

    /** Отладка: сбросить кулдаун. */
    public static void resetCooldown() {
        cooldown = ObserverTuning.GLITCH_COOLDOWN_MIN;
    }
}