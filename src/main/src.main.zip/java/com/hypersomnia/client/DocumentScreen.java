package com.hypersomnia.client;

import com.hypersomnia.document.DocumentDefs;
import com.hypersomnia.document.DocumentDefs.*;
import com.hypersomnia.document.MorseCipher;
import com.hypersomnia.document.EyeAlphabet;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.RandomSource;
import net.minecraft.resources.ResourceLocation;
import com.hypersomnia.Hypersomnia;

import java.util.List;
import java.util.ArrayList;
import java.util.Locale;

/** Страница документа: бумага рисуется заливками, содержимое собирается из элементов DocumentDefs. */
public final class DocumentScreen extends Screen {
    static final int PAPER_W = 200;
    private static final int PAD = 12;
    private static final float GLYPH_W = 18f;
    private static final float GLYPH_STEP = 24f;

    /** Знак глазного алфавита: глаз и точка-метка над ним. */
    private static void glyph(GuiGraphics g, float cx, float cy, EyeAlphabet.Sym s) {
        EyeGlyphs.draw(g, cx, cy, GLYPH_W, s.open(), s.pupil(), 0f, 1f, s.tilt());
        if (s.mark()) {
            int mx = Math.round(cx);
            int my = Math.round(cy - GLYPH_W * 0.34f - 5f);
            g.fill(mx - 1, my - 1, mx + 2, my + 2, 0xFF1E2A34);
        }
    }

    private final Doc doc;

    public DocumentScreen(String id) {
        super(Component.empty());
        this.doc = DocumentDefs.get(id);
    }


    private Screen parent;

    /** Открыт из дневника: по закрытию возвращает в него. */
    public DocumentScreen(String id, Screen parent) {
        this(id);
        this.parent = parent;
    }

    @Override
    public void onClose() {
        if (parent != null && minecraft != null) minecraft.setScreen(parent);
        else super.onClose();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.fill(0, 0, width, height, 0xE0030508);
        if (doc == null) return;

        int h = paperHeight(g);
        int pw = paperWidth();
        float s = Math.min(1.6f, Math.min((height - 16f) / h, (width - 16f) / pw));

        g.pose().pushPose();
        g.pose().translate((width - pw * s) / 2f, (height - h * s) / 2f, 0f);
        g.pose().scale(s, s, 1f);
        drawPaper(g);
        g.pose().popPose();
    }

    private int cachedH = -1;

    /** Ширина листа: у разорванной половинки — половина обычной. */
    int paperWidth() {
        return doc != null && doc.edge() != DocumentDefs.EDGE_NONE ? PAPER_W / 2 : PAPER_W;
    }

    /** Полезная ширина текста: у половинки листа текст доходит до разрыва. */
    private int innerWidth() {
        return doc != null && doc.edge() != DocumentDefs.EDGE_NONE ? paperWidth() - PAD : paperWidth() - PAD * 2;
    }

    /** Левый край строки: у левой половины текст прижат к разрыву, у правой — начинается с него. */
    private int lineX(FormattedCharSequence l, int y) {
        int h = Math.max(1, cachedH);
        if (doc.edge() == DocumentDefs.EDGE_RIGHT) return Math.max(0, spanRight(y, h, paperWidth()) - 1 - font.width(l));
        if (doc.edge() == DocumentDefs.EDGE_LEFT) return spanLeft(y, h);
        return PAD;
    }

    /** Высота страницы (считается один раз). */
    int paperHeight(GuiGraphics g) {
        if (cachedH < 0) cachedH = run(g, false);
        return cachedH;
    }

    /** Ширина / высота страницы; -1, если высота ещё не посчитана (при g = null). */
    float aspect(GuiGraphics g) {
        int h = g != null ? paperHeight(g) : cachedH;
        return h > 0 ? paperWidth() / (float) h : -1f;
    }

    /** Профиль рваной кромки: общий для обеих половин одного листа. */
    private static final int[] TEAR = new int[17];
    static {
        RandomSource r = RandomSource.create(0x7EA41L);
        for (int i = 0; i < TEAR.length; i++) TEAR[i] = r.nextInt(7);
        TEAR[TEAR.length - 1] = TEAR[0];
    }

    /** Смещение излома внутрь листа на высоте y. */
    private int tearAt(int y, int h) {
        float t = h <= 1 ? 0f : y / (float) (h - 1) * (TEAR.length - 1);
        int i = Math.min((int) t, TEAR.length - 2);
        float f = t - i;
        return Math.round(TEAR[i] + (TEAR[i + 1] - TEAR[i]) * f);
    }

    private int spanLeft(int y, int h) {
        return doc.edge() == DocumentDefs.EDGE_LEFT ? tearAt(y, h) : 0;
    }

    private int spanRight(int y, int h, int pw) {
        return doc.edge() == DocumentDefs.EDGE_RIGHT ? pw - tearAt(y, h) : pw;
    }

    /** Вся страница в координатах бумаги (0..paperWidth, 0..paperHeight); дневник масштабирует снаружи. */
    void drawPaper(GuiGraphics g) {
        int h = paperHeight(g);
        int pw = paperWidth();
        boolean note = doc.style() == Style.NOTE;
        boolean torn = doc.edge() != DocumentDefs.EDGE_NONE;
        int base = note ? 0xFFB9B3A5 : doc.style() == Style.DRAWING ? 0xFFDED6C4 : 0xFFC9CFD2;

        // Тень/кант по форме листа: у рваной кромки повторяет излом.
        if (!torn) {
            g.fill(-2, -2, pw + 2, h + 2, 0xFF000000);
            g.fill(0, 0, pw, h, base);
        } else {
            for (int y = 0; y < h; y += 2) {
                g.fill(spanLeft(y, h) - 2, y, spanRight(y, h, pw) + 2, y + 2, 0xFF000000);
            }
            for (int y = 0; y < h; y += 2) {
                int x0 = spanLeft(y, h);
                int x1 = spanRight(y, h, pw);
                g.fill(x0, y, x1, y + 2, base);
                // потемнение у самого излома
                if (doc.edge() == DocumentDefs.EDGE_RIGHT) g.fill(x1 - 1, y, x1, y + 2, 0x28000000);
                else g.fill(x0, y, x0 + 1, y + 2, 0x28000000);
            }
        }
        if (note) { // пятна на мятой бумаге
            RandomSource sr = RandomSource.create(doc.id().hashCode());
            for (int i = 0; i < 7; i++) {
                int x = sr.nextInt(Math.max(1, pw - 38));
                int y = sr.nextInt(Math.max(1, h - 20));
                g.fill(x, y, x + 8 + sr.nextInt(22), y + 3 + sr.nextInt(10), 0x22403020);
            }
        }
        run(g, true);

        if (torn) {
            for (int y = 0; y < h; y += 3) {
                g.fill(spanLeft(y, h), y, spanRight(y, h, pw), y + 1, 0x14000000);
            }
        } else {
            for (int y = 0; y < h; y += 3) g.fill(0, y, pw, y + 1, 0x14000000);
        }
        RandomSource rnd = RandomSource.create(System.nanoTime() / 60_000_000L);
        for (int i = 0; i < 70; i++) {
            int y = rnd.nextInt(h);
            int x0 = spanLeft(y, h);
            int x1 = spanRight(y, h, pw);
            if (x1 - x0 < 1) continue;
            int x = x0 + rnd.nextInt(x1 - x0);
            g.fill(x, y, x + 1, y + 1, ((10 + rnd.nextInt(24)) << 24) | 0xFFFFFF);
        }
    }

    private Component text(int index, String fallback) {
        return Component.translatableWithFallback("hypersomnia.doc." + doc.id() + "." + index, fallback);
    }

    private static ResourceLocation picture(String tex) {
        return ResourceLocation.fromNamespaceAndPath(Hypersomnia.MOD_ID, "textures/misc/" + tex + ".png");
    }

    /** Раскладывает элементы сверху вниз; draw=false только считает высоту страницы. */
    private int run(GuiGraphics g, boolean draw) {
        boolean note = doc.style() == Style.NOTE;
        int ink = note ? 0xFF3A2428 : doc.style() == Style.DRAWING ? 0xFF4A4A55 : 0xFF1E2A34;
        int y = PAD;
        List<El> els = doc.els();

        for (int i = 0; i < els.size(); i++) {
            El el = els.get(i);
            if (el instanceof Head e) {
                if (draw) {
                    g.drawString(font, text(i, e.text()).copy().withStyle(ChatFormatting.BOLD), PAD, y, ink, false);
                    g.fill(PAD, y + 10, PAD + innerWidth(), y + 11, ink);
                }
                y += 16;
            } else if (el instanceof Para e) {
                for (FormattedCharSequence l : font.split(text(i, e.text()), innerWidth())) {
                    if (draw) g.drawString(font, l, lineX(l, y), y, ink, false);
                    y += 10;
                }
                y += 4;
            } else if (el instanceof Strike e) {
                for (FormattedCharSequence l : font.split(text(i, e.text()), innerWidth())) {
                    if (draw) {
                        int x = lineX(l, y);
                        g.drawString(font, l, x, y, ink, false);
                        g.fill(x, y + 4, x + font.width(l), y + 5, ink);
                    }
                    y += 10;
                }
                y += 4;
            } else if (el instanceof Stamp e) {
                Component c = text(i, e.text());
                int tw = font.width(c);
                if (draw) {
                    int x = PAD + innerWidth() - tw - 8;
                    int col = 0xFF8A2030;
                    g.fill(x - 4, y - 2, x + tw + 4, y - 1, col);
                    g.fill(x - 4, y + 10, x + tw + 4, y + 11, col);
                    g.fill(x - 4, y - 2, x - 3, y + 11, col);
                    g.fill(x + tw + 3, y - 2, x + tw + 4, y + 11, col);
                    g.drawString(font, c, x, y, col, false);
                }
                y += 18;
            } else if (el instanceof Letters e) {
                for (char ch : e.text().toUpperCase().toCharArray()) {
                    if (ch < 'A' || ch > 'Z') {
                        y += 6;
                        continue;
                    }
                    int n = ch - 'A' + 1;
                    float step = Math.min(7f, innerWidth() / (float) n);
                    if (draw) {
                        for (int k = 0; k < n; k++) {
                            EyeGlyphs.draw(g, PAD + step * (k + 0.5f), y + 3f, step - 1f, 1f, 0f, 0f, 1f);
                        }
                    }
                    y += 8;
                }
                y += 6;
            } else if (el instanceof Morse e) {
                y = HeartMorse.draw(g, draw, PAD, y, innerWidth(), text(i, e.text()).getString(), e.printed());
            } else if (el instanceof Marked e) {
                // Шифр 1: слова между * помечены глазом, первые буквы помеченных слов дают слово
                float x = PAD;
                float space = font.width(" ");
                for (String token : text(i, e.text()).getString().split(" ")) {
                    boolean marked = token.indexOf('*') >= 0;
                    String word = token.replace("*", "");
                    int w = font.width(word);
                    if (x > PAD && x + w > PAD + innerWidth()) {
                        x = PAD;
                        y += 16;
                    }
                    if (draw) {
                        g.drawString(font, word, (int) x, y + 7, ink, false);
                        if (marked) EyeGlyphs.draw(g, x + w / 2f, y + 3f, 9f, 1f, 0f, 0f, 1f);
                    }
                    x += w + space;
                }
                y += 20;
            } else if (el instanceof Glyphs e) {
                // Шифр 2: глазной алфавит, слово не рвётся между строками.
                // Знаки, которым игрок уже назначил букву в дневнике, показываются буквой.
                float x = PAD;
                for (String word : text(i, e.text()).getString().toUpperCase(Locale.ROOT).split(" ")) {
                    List<Character> syms = new ArrayList<>();
                    for (char ch : word.toCharArray()) {
                        if (EyeAlphabet.symbol(ch) != null) syms.add(ch);
                    }
                    if (syms.isEmpty()) continue;
                    float w = syms.size() * GLYPH_STEP;
                    if (x > PAD && x + w > PAD + innerWidth()) {
                        x = PAD;
                        y += 28;
                    }
                    if (draw) {
                        for (int k = 0; k < syms.size(); k++) {
                            char ch = syms.get(k);
                            float cx = x + GLYPH_STEP * k + GLYPH_STEP / 2f;
                            Character known = DiaryClientState.letterFor(ch);
                            if (known != null) {
                                String s = String.valueOf(known);
                                g.drawString(font, s, (int) (cx - font.width(s) / 2f), y + 8, 0xFF8A2030, false);
                            } else {
                                glyph(g, cx, y + 12f, EyeAlphabet.symbol(ch));
                            }
                        }
                    }
                    x += w + 10f;
                }
                y += 30;
            } else if (el instanceof GlyphKey e) {
                // Фрагмент ключа: знак и буква рядом, по 4 пары в строке
                int col = 0;
                for (char ch : text(i, e.letters()).getString().toUpperCase(Locale.ROOT).toCharArray()) {
                    EyeAlphabet.Sym s = EyeAlphabet.symbol(ch);
                    if (s == null) continue;
                    if (col == 4) {
                        col = 0;
                        y += 28;
                    }
                    if (draw) {
                        float x = PAD + col * 44f;
                        glyph(g, x + 12f, y + 12f, s);
                        g.drawString(font, String.valueOf(ch), (int) (x + 28f), y + 8, ink, false);
                    }
                    col++;
                }
                y += 30;
            } else if (el instanceof Dirs e) {
                float x = PAD;
                for (char ch : e.dirs().toUpperCase().toCharArray()) {
                    float dx = ch == 'L' ? -1f : ch == 'R' ? 1f : 0f;
                    float dy = ch == 'U' ? -1f : ch == 'D' ? 1f : 0f;
                    if (draw) EyeGlyphs.draw(g, x + 8f, y + 6f, 16f, 1f, dx, dy, 1f);
                    x += 20f;
                }
                y += 16;
            } else if (el instanceof Picture e) {
                if (draw) g.blit(picture(e.tex()), PAD, y, 0, 0f, 0f, innerWidth(), e.h(), innerWidth(), e.h());
                y += e.h() + 6;
            } else if (el instanceof Gap) {
                y += 8;
            }
        }
        return y + PAD - 4;
    }
}