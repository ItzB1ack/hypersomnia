package com.hypersomnia.client;

import com.hypersomnia.ObserverTuning;

/**
 * Клиентский «режиссёр» наблюдателя: бюджет страха, один эпизод за раз, гарантированная тишина.
 * Эпизоды: GHOST (призрак в мире), DOOR (серия звука двери), SCARE (кадр-сюрприз внутри эпизода призрака).
 * Без клиентских импортов Minecraft. Числа только в ObserverTuning (DIRECTOR_*).
 */
public final class ObserverDirector {
    private ObserverDirector() {}

    public enum Kind { GHOST, DOOR, SCARE }

    private static final int N = Kind.values().length;
    private static float budget = ObserverTuning.DIRECTOR_BUDGET_START;
    private static int silence = ObserverTuning.DIRECTOR_SILENCE_AT_START;
    private static final int[] cooldown = new int[N];
    /** Идущий сейчас эпизод GHOST или DOOR (SCARE блокировку не берёт). */
    private static Kind lock;

    /** Раз в тик (не на паузе). pressure 0..1, stage 0..5. */
    public static void tick(float pressure, int stage) {
        budget = Math.min(ObserverTuning.DIRECTOR_BUDGET_CAP, budget
                + ObserverTuning.DIRECTOR_REGEN_BASE
                + ObserverTuning.DIRECTOR_REGEN_PER_PRESSURE * pressure
                + ObserverTuning.DIRECTOR_REGEN_PER_STAGE * stage);
        if (silence > 0) silence--;
        for (int i = 0; i < N; i++) if (cooldown[i] > 0) cooldown[i]--;
    }

    public static boolean can(Kind k) {
        int i = k.ordinal();
        if (cooldown[i] > 0 || budget < ObserverTuning.DIRECTOR_COST[i]) return false;
        if (k == Kind.SCARE) return true; // идёт внутри эпизода призрака, тишина и блокировка не мешают
        return silence <= 0 && lock == null;
    }

    /** Пытается начать эпизод: true = разрешено, бюджет списан, блокировка взята. */
    public static boolean begin(Kind k) {
        if (!can(k)) return false;
        int i = k.ordinal();
        budget -= ObserverTuning.DIRECTOR_COST[i];
        if (k == Kind.SCARE) cooldown[i] = ObserverTuning.DIRECTOR_KIND_COOLDOWN[i];
        else lock = k;
        return true;
    }

    /** Конец эпизода (можно вызывать лишний раз: без блокировки этого вида ничего не делает). */
    public static void end(Kind k) {
        if (lock != k) return;
        lock = null;
        cooldown[k.ordinal()] = ObserverTuning.DIRECTOR_KIND_COOLDOWN[k.ordinal()];
        silence = Math.max(silence, ObserverTuning.DIRECTOR_SILENCE_AFTER);
    }

    /** Игрок проснулся / вышел из мира снов: долгая тишина, чтобы найти следы и записки. */
    public static void onWake() {
        silence = Math.max(silence, ObserverTuning.DIRECTOR_SILENCE_AFTER_WAKE);
    }

    /** Отладка: полный бюджет, без тишины и кулдаунов. */
    public static void fill() {
        budget = ObserverTuning.DIRECTOR_BUDGET_CAP;
        silence = 0;
        java.util.Arrays.fill(cooldown, 0);
    }

    public static String status() {
        return String.format("Director: budget %.0f/%.0f, silence %d, lock %s, cooldowns G%d D%d S%d",
                budget, ObserverTuning.DIRECTOR_BUDGET_CAP, silence, lock,
                cooldown[0], cooldown[1], cooldown[2]);
    }

    public static void reset() {
        budget = ObserverTuning.DIRECTOR_BUDGET_START;
        silence = ObserverTuning.DIRECTOR_SILENCE_AT_START;
        lock = null;
        java.util.Arrays.fill(cooldown, 0);
    }
}