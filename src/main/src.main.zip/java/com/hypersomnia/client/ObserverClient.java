package com.hypersomnia.client;

import com.hypersomnia.FatigueTuning;
import com.hypersomnia.Hypersomnia;
import com.hypersomnia.ObserverTuning;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterClientCommandsEvent;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.joml.Vector3f;
import net.minecraft.core.Direction;
import net.minecraft.client.renderer.LightTexture;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;

/**
 * Наблюдатель: отколовшаяся часть игрока. Клиентский «призрак» (в мир не добавляется).
 * <p>
 * Реальный мир: появляется на периферии зрения, в темноте; исчезает, когда на него смотрят;
 * пока игрок не смотрит, делает шаги ближе. К игроку вплотную не подходит и ничего ему не делает.
 * Мир снов (hypersomnia:dream): правило ломается, он не исчезает, а подходит, пока на него смотрят.
 */
@EventBusSubscriber(modid = Hypersomnia.MOD_ID, value = Dist.CLIENT)
public final class ObserverClient {
    private ObserverClient() {
    }

    private static final RandomSource RANDOM = RandomSource.create();
    private static final ResourceLocation DREAM_DIMENSION =
            ResourceLocation.fromNamespaceAndPath(Hypersomnia.MOD_ID, "dream");
    private static final double EYE_HEIGHT = 1.62;

    private static ObserverGhost ghost;
    private static Vec3 pos = Vec3.ZERO;
    private static int age;
    private static int gazeTicks;
    private static int ticksUntilSpawn = -1;
    private static int stepCooldown;
    /**
     * Осколок у кровати: он сейчас стоит рядом с лежащим игроком / бросок на это засыпание уже сделан.
     */
    private static boolean bedWatch;
    private static boolean bedRolled;
    private static boolean wasLooking;
    private static boolean wasAway;
    private static boolean covered;

    /**
     * Отладка: появляется всегда, независимо от усталости, света и режима игры.
     */
    private static boolean debugForce;
    /** Один эпизод неподвижности: спавн у края поля зрения вместо «за кадром». */
    private static boolean peripherySpawn = false;
    /** Тики, в которые силуэт не исчезает (после периферийного спавна). */
    private static int forcedVisibleTicks = 0;
    private static int pendingVisibleTicks = 0;
    /** Пока true, обычный периодический спавн не запускается (ImmobilityClient ждёт). */
    public static boolean deferSpawn = false;

    // ------------------------------------------------------------------
    // Тик
    // ------------------------------------------------------------------
    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null) {
            despawn();
            ticksUntilSpawn = -1;
            return;
        }
        if (mc.isPaused()) return;
        ObserverScare.tick();
        ObserverDirector.tick(pressure(), ObserverState.stage());
        boolean away = player.isSleeping() || isDream(mc);
        if (wasAway && !away) ObserverDirector.onWake();
        wasAway = away;

        // Сменился мир (например, ушли в измерение): призрак принадлежал старому миру
        if (ghost != null && ghost.level() != mc.level) despawn();

        // Лежит в кровати в Верхнем мире: отдельное поведение осколка
        if (player.isSleeping() && !isDream(mc)) {
            tickBedWatch(mc, player);
            return;
        }
        bedRolled = false;
        if (bedWatch) {
            bedWatch = false;
            if (ghost != null) vanish(); // игрок проснулся: оно исчезает
        }

        if (!isEligible(mc, player)) {
            despawn();
            ticksUntilSpawn = -1;
            return;
        }

        if (deferSpawn) return;

        if (ghost == null) {
            if (ticksUntilSpawn < 0) scheduleSpawn();
            if (--ticksUntilSpawn <= 0 && !trySpawn(mc, player)) {
                ticksUntilSpawn = 40; // не нашли место: повторим через 2 секунды
            }
            return;
        }
        tickGhost(mc, player);
    }

    private static boolean isEligible(Minecraft mc, LocalPlayer player) {
        // Эпизод неподвижности уже поставил фигуру: держим её, пока forcedVisibleTicks > 0.
        if (forcedVisibleTicks > 0) return true;
        if (peripherySpawn) return true;
        if (debugForce) return true;
        if (player.isCreative() || player.isSpectator() || !player.isAlive() || player.isSleeping()) return false;
        if (ClientFatigueState.collapsing) return false;
        if (isDream(mc)) return true;
        float threshold = ObserverState.madness > 0
                ? ObserverTuning.START_RATIO_AFTER_MADNESS
                : ObserverTuning.START_RATIO;
        if (SyringeClientState.active) return true; // искусственное бодрствование привлекает Осколка
        return ClientFatigueState.ratio() >= threshold;
    }

    private static boolean isDream(Minecraft mc) {
        return mc.level != null && mc.level.dimension().location().equals(DREAM_DIMENSION);
    }

    /**
     * 0..1: растёт и с усталостью, и с безумием.
     */
    private static float pressure() {
        float threshold = ObserverState.madness > 0
                ? ObserverTuning.START_RATIO_AFTER_MADNESS
                : ObserverTuning.START_RATIO;
        float fatigueP = FatigueTuning.progress(ClientFatigueState.ratio(), threshold);
        float madnessP = Math.min(ObserverState.madness, ObserverTuning.MADNESS_CAP)
                / (float) ObserverTuning.MADNESS_CAP;
        return Mth.clamp(fatigueP * 0.5f + madnessP * 0.5f + SyringeClientState.observerBoost(), 0f, 1f);
    }

    private static void scheduleSpawn() {
        int base = Mth.lerpInt(pressure(), ObserverTuning.SPAWN_INTERVAL_MAX, ObserverTuning.SPAWN_INTERVAL_MIN);
        ticksUntilSpawn = (int) (base * (0.7f + RANDOM.nextFloat() * 0.6f));
    }

    // ------------------------------------------------------------------
    // Появление
    // ------------------------------------------------------------------
    private static boolean trySpawn(Minecraft mc, LocalPlayer player) {
        Level level = mc.level;
        boolean periphery = peripherySpawn;
        peripherySpawn = false;
        if (!debugForce && !periphery && !ObserverDirector.can(ObserverDirector.Kind.GHOST)) return false;
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        double len = Math.hypot(look.x, look.z);
        if (len < 1.0E-4) return false;
        double hx = look.x / len;
        double hz = look.z / len;

        // Обычный спавн — за краем поля зрения: игрок заметит, только повернувшись.
        // Периферийный (эпизод неподвижности) — строго сзади, там же, где был шаг.
        double halfHorizontalDeg = Math.toDegrees(Math.atan(tanHalfVertical(mc) * aspect(mc)));
        float minDeg;
        float maxDeg;
        if (periphery) {
            minDeg = 180f - ObserverTuning.STILL_BEHIND_SPREAD_DEG;
            maxDeg = 180f + ObserverTuning.STILL_BEHIND_SPREAD_DEG;
        } else {
            float minDegBase = (float) Math.min(halfHorizontalDeg + ObserverTuning.SPAWN_OUTSIDE_VIEW_MARGIN, 120.0);
            minDeg = minDegBase;
            maxDeg = Math.min(minDegBase + ObserverTuning.SPAWN_ANGLE_SPREAD, 160f);
        }

        // Обычное появление чаще в укрытии (дерево / окно); периферийный спавн эпизода неподвижности сюда не относится
        if (!periphery && RANDOM.nextFloat() < ObserverTuning.COVER_CHANCE
                && trySpawnCovered(mc, player, eye, hx, hz, minDeg)) return true;
        int attempts = periphery ? 32 : 16;
        for (int i = 0; i < attempts; i++) {
            float deg = Mth.lerp(RANDOM.nextFloat(), minDeg, maxDeg);
            int sign = periphery ? 1 : (RANDOM.nextBoolean() ? 1 : -1);
            double rad = Math.toRadians(deg) * sign;
            double c = Math.cos(rad);
            double s = Math.sin(rad);
            double dx = hx * c - hz * s;
            double dz = hx * s + hz * c;
            double dist = periphery
                    ? Mth.lerp(RANDOM.nextFloat(), ObserverTuning.STILL_DISTANCE_MIN, ObserverTuning.STILL_DISTANCE_MAX)
                    : Mth.lerp(RANDOM.nextFloat(), ObserverTuning.SPAWN_DISTANCE_MIN, ObserverTuning.SPAWN_DISTANCE_MAX);

            int x = Mth.floor(player.getX() + dx * dist);
            int z = Mth.floor(player.getZ() + dz * dist);
            BlockPos stand = findStandPos(level, x, z, player.getBlockY());
            if (stand == null) continue;
            if (!debugForce && !periphery && !isDream(mc) && level.getMaxLocalRawBrightness(stand) > ObserverTuning.MAX_LIGHT)
                continue;

            Vec3 feet = new Vec3(stand.getX() + 0.5, stand.getY(), stand.getZ() + 0.5);
            if (!hasLineOfSight(level, player, eye, feet.add(0, EYE_HEIGHT, 0))) continue;

            ghost = new ObserverGhost(mc.level);
            pos = feet;
            age = 0;
            gazeTicks = 0;
            stepCooldown = Mth.randomBetweenInclusive(RANDOM, ObserverTuning.STEP_COOLDOWN_MIN, ObserverTuning.STEP_COOLDOWN_MAX);
            placeGhost(player);
            if (!debugForce && !periphery) ObserverDirector.begin(ObserverDirector.Kind.GHOST);
            if (periphery && pendingVisibleTicks > 0) {
                forcedVisibleTicks = pendingVisibleTicks;
                pendingVisibleTicks = 0;
            }
            return true;
        }
        return false;
    }


    /** Появление в укрытии: за стволом дерева или за стеклом окна. Стоит на месте и наблюдает. */
    private static boolean trySpawnCovered(Minecraft mc, LocalPlayer player, Vec3 eye, double hx, double hz, float minDeg) {
        Level level = mc.level;
        java.util.function.Predicate<Vec3> ok = f -> {
            BlockPos cell = BlockPos.containing(f.x, f.y + 0.1, f.z);
            if (!debugForce && !isDream(mc) && level.getMaxLocalRawBrightness(cell) > ObserverTuning.MAX_LIGHT) return false;
            return hasLineOfSight(level, player, eye, f.add(0, EYE_HEIGHT, 0));
        };

        Vec3 feet = null;
        if (RANDOM.nextFloat() < ObserverTuning.COVER_WINDOW_SHARE) {
            feet = ObserverCover.findWindow(level, player, hx, hz, minDeg, RANDOM, ok);
        }
        float maxDeg = Math.min(minDeg + ObserverTuning.SPAWN_ANGLE_SPREAD, 160f);
        for (int i = 0; feet == null && i < ObserverTuning.COVER_ATTEMPTS; i++) {
            float deg = Mth.lerp(RANDOM.nextFloat(), minDeg, maxDeg);
            double rad = Math.toRadians(deg) * (RANDOM.nextBoolean() ? 1 : -1);
            double c = Math.cos(rad);
            double s = Math.sin(rad);
            double dx = hx * c - hz * s;
            double dz = hx * s + hz * c;
            double dist = Mth.lerp(RANDOM.nextFloat(), ObserverTuning.SPAWN_DISTANCE_MIN, ObserverTuning.SPAWN_DISTANCE_MAX);
            int x = Mth.floor(player.getX() + dx * dist);
            int z = Mth.floor(player.getZ() + dz * dist);
            feet = ObserverCover.findTree(level, player, x, z, hx, hz, minDeg, RANDOM, ok);
        }
        if (feet == null) return false;

        ghost = new ObserverGhost(mc.level);
        pos = feet;
        age = 0;
        gazeTicks = 0;
        covered = true;
        stepCooldown = Mth.randomBetweenInclusive(RANDOM, ObserverTuning.STEP_COOLDOWN_MIN, ObserverTuning.STEP_COOLDOWN_MAX);
        placeGhost(player);
        if (!debugForce) ObserverDirector.begin(ObserverDirector.Kind.GHOST);
        return true;
    }

    /**
     * Игрок лежит в кровати в Верхнем мире. Со стадии 2 осколок встаёт рядом, молчит и чуть подкрадывается.
     */
    private static void tickBedWatch(Minecraft mc, LocalPlayer player) {
        // Обычный призрак, уже стоявший в мире, при засыпании исчезает
        if (ghost != null && !bedWatch) {
            vanish();
            return;
        }
        // Идёт сцена в кровати: у неё своя фигура
        if (SleepSceneState.silent()) {
            if (bedWatch) {
                despawn();
                bedWatch = false;
            }
            return;
        }
        if (bedWatch) {
            if (ghost == null) {
                bedWatch = false;
                return;
            }
            ghost.tickCount++;
            age++;
            double dist = player.getEyePosition().distanceTo(pos.add(0, EYE_HEIGHT, 0));
            if (dist > ObserverTuning.BED_WATCH_STOP_DISTANCE) {
                moveToward(mc.level, player, ObserverTuning.BED_WATCH_CREEP_SPEED);
            }
            placeGhost(player);
            return;
        }

        int stage = ObserverState.stage();
        if (bedRolled || stage < ObserverTuning.BED_WATCH_MIN_STAGE
                || player.getSleepTimer() < ObserverTuning.BED_WATCH_DELAY_TICKS) return;
        bedRolled = true;
        float chance = Math.min(1f, ObserverTuning.BED_WATCH_CHANCE_BASE
                + ObserverTuning.BED_WATCH_CHANCE_PER_STAGE * (stage - ObserverTuning.BED_WATCH_MIN_STAGE));
        if (RANDOM.nextFloat() >= chance) return;
        if (trySpawnAtBed(mc, player)) bedWatch = true;
    }

    /**
     * Ставит осколка в 2.6-3.4 блока от кровати, в той стороне, куда смотрит лежащий игрок.
     */
    private static boolean trySpawnAtBed(Minecraft mc, LocalPlayer player) {
        Level level = mc.level;
        Vec3 eye = player.getEyePosition();
        // В кровати камера смотрит от изголовья к ногам: берём направление от кровати, а не от взгляда игрока
        double hx;
        double hz;
        Direction bed = player.getBedOrientation();
        if (bed != null) {
            hx = -bed.getStepX();
            hz = -bed.getStepZ();
        } else {
            Vec3 look = player.getLookAngle();
            double len = Math.hypot(look.x, look.z);
            if (len < 1.0E-4) return false;
            hx = look.x / len;
            hz = look.z / len;
        }

        for (int i = 0; i < 16; i++) {
            double rad = Math.toRadians((RANDOM.nextFloat() - 0.5f) * 2f * ObserverTuning.BED_WATCH_SPREAD_DEG);
            double c = Math.cos(rad);
            double s = Math.sin(rad);
            double dx = hx * c - hz * s;
            double dz = hx * s + hz * c;
            double dist = Mth.lerp(RANDOM.nextFloat(),
                    ObserverTuning.BED_WATCH_DISTANCE_MIN, ObserverTuning.BED_WATCH_DISTANCE_MAX);
            int x = Mth.floor(player.getX() + dx * dist);
            int z = Mth.floor(player.getZ() + dz * dist);
            BlockPos stand = findStandPos(level, x, z, player.getBlockY());
            if (stand == null) continue;

            Vec3 feet = new Vec3(stand.getX() + 0.5, stand.getY(), stand.getZ() + 0.5);
            if (!hasLineOfSight(level, player, eye, feet.add(0, EYE_HEIGHT, 0))) continue;

            ghost = new ObserverGhost(mc.level);
            pos = feet;
            age = 0;
            gazeTicks = 0;
            placeGhost(player);
            return true;
        }
        return false;
    }

    /**
     * Ищет, где можно встать: сверху вниз ищем клетку с твёрдым полом и двумя свободными клетками над ним.
     */
    private static BlockPos findStandPos(Level level, int x, int z, int aroundY) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();
        for (int y = aroundY + 6; y >= aroundY - 12; y--) {
            p.set(x, y, z);
            if (!level.hasChunkAt(p)) return null;
            if (!isFree(level, p) || !isFree(level, p.above())) continue;
            BlockPos below = p.below();
            if (level.getBlockState(below).getCollisionShape(level, below).isEmpty()) continue;
            if (!level.getFluidState(below).isEmpty()) continue;
            return p.immutable();
        }
        return null;
    }

    private static boolean isFree(Level level, BlockPos pos) {
        return level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()
                && level.getFluidState(pos).isEmpty();
    }

    private static boolean hasLineOfSight(Level level, LocalPlayer player, Vec3 from, Vec3 to) {
        return ObserverCover.hasSight(level, player, from, to);
    }

    // ------------------------------------------------------------------
    // Поведение
    // ------------------------------------------------------------------
    private static void tickGhost(Minecraft mc, LocalPlayer player) {
        age++;
        ghost.tickCount++;
        if (forcedVisibleTicks > 0) {
            forcedVisibleTicks--;
            if (forcedVisibleTicks == 0) {
                vanish();
                return;
            }
            placeGhost(player);
            return;
        }

        Vec3 eye = player.getEyePosition();
        Vec3 head = pos.add(0, EYE_HEIGHT, 0);
        double dist = eye.distanceTo(head);
        int view = viewState(mc, player, eye);
        boolean looking = view == VIEW_VISIBLE;      // в поле зрения и ничем не закрыт
        boolean inFov = view != VIEW_OUTSIDE;        // хотя бы часть тела попадает в кадр
        int madness = ObserverState.madness;
        boolean justSeen = looking && !wasLooking; // первый тик, когда игрок его заметил
        wasLooking = looking;

        if (isDream(mc)) {
            int stage = ObserverState.stage();
            if (stage < ObserverTuning.DREAM_APPROACH_MIN_STAGE) {
                // Ранние стадии: стоит на месте, от взгляда исчезает; со стадии SCARE_MIN_STAGE при этом кадр-сюрприз
                if (looking) {
                    int need = Math.min(ObserverTuning.GAZE_TICKS_BASE + madness * ObserverTuning.GAZE_TICKS_PER_MADNESS,
                            ObserverTuning.GAZE_TICKS_MAX);
                    if (++gazeTicks >= need) {
                        if (stage >= ObserverTuning.SCARE_MIN_STAGE
                                && ObserverDirector.begin(ObserverDirector.Kind.SCARE)) ObserverScare.trigger(stage);
                        vanish();
                        return;
                    }
                } else if (gazeTicks > 0) {
                    gazeTicks--;
                }
                int lifetime = Math.min(ObserverTuning.LIFETIME_BASE + madness * ObserverTuning.LIFETIME_PER_MADNESS,
                        ObserverTuning.LIFETIME_MAX);
                if (age > lifetime) {
                    vanish();
                    return;
                }
            } else {
                // Поздние стадии: не исчезает, заметили его (кадр) и пока смотришь, он идёт к тебе
                if (justSeen && ObserverDirector.begin(ObserverDirector.Kind.SCARE)) ObserverScare.trigger(stage);
                if (looking && dist > ObserverTuning.DREAM_STOP_DISTANCE) {
                    double speed = ObserverTuning.DREAM_APPROACH_SPEED + madness * ObserverTuning.DREAM_APPROACH_PER_MADNESS;
                    moveToward(mc.level, player, speed);
                }
            }

        } else {
            // Правило реального мира: исчезает, когда на него смотрят
            if (looking) {
                int need = Math.min(ObserverTuning.GAZE_TICKS_BASE + madness * ObserverTuning.GAZE_TICKS_PER_MADNESS,
                        ObserverTuning.GAZE_TICKS_MAX) + (covered ? ObserverTuning.COVER_GAZE_TICKS_BONUS : 0);
                if (++gazeTicks >= need) {
                    vanish();
                    return;
                }
            } else if (gazeTicks > 0) {
                gazeTicks--;
            }

            int lifetime = Math.min(ObserverTuning.LIFETIME_BASE + madness * ObserverTuning.LIFETIME_PER_MADNESS,
                    ObserverTuning.LIFETIME_MAX);
            if (covered) lifetime = (int) (lifetime * ObserverTuning.COVER_LIFETIME_MULT);
            if (dist < ObserverTuning.NEAR_VANISH || dist > ObserverTuning.FAR_VANISH || age > lifetime) {
                vanish();
                return;
            }

            // Пока игрок не смотрит, подходит на шаг-другой
            if (!covered && !inFov && --stepCooldown <= 0) {
                stepCooldown = Mth.randomBetweenInclusive(RANDOM, ObserverTuning.STEP_COOLDOWN_MIN, ObserverTuning.STEP_COOLDOWN_MAX);
                float limit = Math.max(ObserverTuning.APPROACH_LIMIT_FLOOR,
                        ObserverTuning.APPROACH_LIMIT_BASE - madness * ObserverTuning.APPROACH_LIMIT_PER_MADNESS);
                if (dist > limit) {
                    float step = Mth.lerp(RANDOM.nextFloat(), ObserverTuning.STEP_DISTANCE_MIN, ObserverTuning.STEP_DISTANCE_MAX);
                    moveToward(mc.level, player, Math.min(step, dist - limit));
                }
            }
        }
        placeGhost(player);
    }

    /**
     * Сдвигает призрака к игроку по горизонтали на distance блоков, с подстройкой по высоте.
     */
    private static void moveToward(Level level, LocalPlayer player, double distance) {
        double dx = player.getX() - pos.x;
        double dz = player.getZ() - pos.z;
        double len = Math.hypot(dx, dz);
        if (len < 1.0E-4) return;
        double nx = pos.x + dx / len * distance;
        double nz = pos.z + dz / len * distance;
        BlockPos stand = findStandPos(level, Mth.floor(nx), Mth.floor(nz), Mth.floor(pos.y));
        if (stand == null) return;
        pos = new Vec3(nx, stand.getY(), nz);
    }

    private static final int VIEW_OUTSIDE = 0;   // вне поля зрения
    private static final int VIEW_BLOCKED = 1;   // в поле зрения, но закрыт блоками
    private static final int VIEW_VISIBLE = 2;   // игрок реально его видит
    private static final double[] BODY_POINTS = {0.15, 0.9, EYE_HEIGHT}; // ноги, торс, голова

    private static double tanHalfVertical(Minecraft mc) {
        return Math.tan(Math.toRadians(mc.options.fov().get() / 2.0));
    }

    private static double aspect(Minecraft mc) {
        return mc.getWindow().getWidth() / (double) Math.max(1, mc.getWindow().getHeight());
    }

    /**
     * Попадает ли тело в прямоугольник экрана (с учётом FOV и пропорций окна)
     * и видно ли его на самом деле. Достаточно, чтобы хоть одна из трёх точек тела была на экране.
     */
    private static int viewState(Minecraft mc, LocalPlayer player, Vec3 eye) {
        if (mc.screen != null) return VIEW_OUTSIDE;

        Vec3 look = player.getViewVector(1.0f);
        Vec3 right = look.cross(new Vec3(0, 1, 0));
        double rl = right.length();
        if (rl < 1.0E-4) return VIEW_OUTSIDE; // смотрит строго вверх/вниз
        right = right.scale(1.0 / rl);
        Vec3 up = right.cross(look);

        double tv = tanHalfVertical(mc) * ObserverTuning.VIEW_MARGIN;
        double th = tv * aspect(mc);

        int result = VIEW_OUTSIDE;
        for (double off : BODY_POINTS) {
            Vec3 target = pos.add(0, off, 0);
            Vec3 v = target.subtract(eye);
            double z = v.dot(look);
            if (z <= 0.1) continue;
            if (Math.abs(v.dot(right) / z) > th || Math.abs(v.dot(up) / z) > tv) continue;

            if (hasLineOfSight(mc.level, player, eye, target)) return VIEW_VISIBLE;
            result = VIEW_BLOCKED;
        }
        return result;
    }

    /**
     * Ставит призрака в позицию и поворачивает лицом (и головой) к игроку.
     */
    private static void placeGhost(LocalPlayer player) {
        ghost.setPos(pos.x, pos.y, pos.z);
        ghost.setOldPosAndRot();

        double dx = player.getX() - pos.x;
        double dz = player.getZ() - pos.z;
        double dy = player.getEyeY() - (pos.y + EYE_HEIGHT);
        float yaw = (float) (Mth.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
        float pitch = (float) -(Mth.atan2(dy, Math.hypot(dx, dz)) * (180.0 / Math.PI));

        ghost.setYRot(yaw);
        ghost.setXRot(pitch);
        ghost.setYBodyRot(yaw);
        ghost.setYHeadRot(yaw);
        ghost.yBodyRotO = yaw;
        ghost.yHeadRotO = yaw;
        ghost.setOldPosAndRot();
    }

    /**
     * Принудительный спавн у края поля зрения (эпизод неподвижности). Снимает deferSpawn.
     */
    public static boolean tryPeripherySpawn() {
        deferSpawn = false;
        if (ghost != null) despawn();
        ticksUntilSpawn = 1;
        peripherySpawn = true;
        pendingVisibleTicks = ObserverTuning.STILL_VISIBLE_TICKS;
        return true;
    }

    public static boolean hasGhost() {
        return ghost != null;
    }


    private static void despawn() {
        ObserverDirector.end(ObserverDirector.Kind.GHOST);
        covered = false;
        wasLooking = false;
        forcedVisibleTicks = 0;
        pendingVisibleTicks = 0;
        peripherySpawn = false;
        ghost = null;
        age = 0;
        gazeTicks = 0;
    }

    /**
     * Исчезновение без звука и частиц; следующее появление планируется заново.
     */
    private static void vanish() {
        spawnVanishParticles();
        despawn();
        scheduleSpawn();
    }

    /**
     * Облако чёрных частиц на месте, где он стоял.
     */
    private static void spawnVanishParticles() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || ghost == null) return;

        DustParticleOptions dust = new DustParticleOptions(new Vector3f(0f, 0f, 0f), 1.6f);
        for (int i = 0; i < ObserverTuning.VANISH_DUST_COUNT; i++) {
            mc.level.addParticle(dust,
                    pos.x + (RANDOM.nextDouble() - 0.5) * 0.7,
                    pos.y + RANDOM.nextDouble() * 1.9,
                    pos.z + (RANDOM.nextDouble() - 0.5) * 0.7,
                    (RANDOM.nextDouble() - 0.5) * 0.08,
                    RANDOM.nextDouble() * 0.06,
                    (RANDOM.nextDouble() - 0.5) * 0.08);
        }
        for (int i = 0; i < ObserverTuning.VANISH_INK_COUNT; i++) {
            mc.level.addParticle(ParticleTypes.SQUID_INK,
                    pos.x + (RANDOM.nextDouble() - 0.5) * 0.6,
                    pos.y + RANDOM.nextDouble() * 1.8,
                    pos.z + (RANDOM.nextDouble() - 0.5) * 0.6,
                    (RANDOM.nextDouble() - 0.5) * 0.04,
                    RANDOM.nextDouble() * 0.04,
                    (RANDOM.nextDouble() - 0.5) * 0.04);
        }
    }

    // ------------------------------------------------------------------
    // Рендер: рисуем фигуру как обычную сущность, но без добавления в мир
    // ------------------------------------------------------------------
    @SubscribeEvent
    public static void onRenderLevel(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) return;
        if (ghost == null) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || ghost.level() != mc.level) return;

        Vec3 cam = event.getCamera().getPosition();
        float partial = event.getPartialTick().getGameTimeDeltaPartialTick(false);
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        int light = LevelRenderer.getLightColor(mc.level, BlockPos.containing(pos.x, pos.y + 1.0, pos.z));
        if (bedWatch) {
            light = LightTexture.pack(Math.max(LightTexture.block(light), ObserverTuning.BED_WATCH_MIN_LIGHT),
                    LightTexture.sky(light));
        }

        PoseStack ps = event.getPoseStack();
        float t = age + partial;
        boolean eyes = isDream(mc) || (mc.player != null
                && mc.player.position().distanceTo(pos) < ObserverTuning.EYES_DISTANCE);
        double rad = Math.toRadians(ghost.getYRot());
        double side = Math.sin(t * ObserverTuning.ECHO_SPEED) * ObserverTuning.ECHO_OFFSET;
        for (int pass = 0; pass < 2; pass++) {
            boolean echo = pass == 0;
            ghost.variant = echo ? ObserverGhost.ECHO : (eyes ? ObserverGhost.EYES : ObserverGhost.BODY);
            float w = (1f + ObserverTuning.GHOST_WOBBLE * Mth.sin(t * ObserverTuning.GHOST_WOBBLE_SPEED + pass * 1.7f))
                    * (echo ? 1.04f : 1f);
            ps.pushPose();
            ps.translate(pos.x - cam.x + (echo ? Math.cos(rad) * side : 0), pos.y - cam.y,
                    pos.z - cam.z + (echo ? Math.sin(rad) * side : 0));
            ps.scale(ObserverTuning.GHOST_SCALE_XZ * w, ObserverTuning.GHOST_SCALE_Y, ObserverTuning.GHOST_SCALE_XZ * w);
            mc.getEntityRenderDispatcher().render(ghost, 0, 0, 0, ghost.getYRot(), partial, ps, buffers, light);
            if (!echo && eyes) drawFaceEyes(ps, buffers, t);
            ps.popPose();
        }
        buffers.endBatch();
    }

    private static ResourceLocation eyeTex(String layer, boolean mirrored) {
        return ResourceLocation.fromNamespaceAndPath(Hypersomnia.MOD_ID,
                "textures/misc/silhouette_eye_" + layer + (mirrored ? "_r" : "") + ".png");
    }

    /**
     * [слой][0 = глаз слева от зрителя (зеркальная текстура), 1 = справа]; слои: склера, радужка, веки.
     */
    private static final ResourceLocation[][] EYE_TEX = {
            {eyeTex("sclera", true), eyeTex("sclera", false)},
            {eyeTex("iris", true), eyeTex("iris", false)},
            {eyeTex("lids", true), eyeTex("lids", false)}
    };

    private static float eyeBlink(long ms, int period, int phase) {
        long ph = (ms + phase) % period;
        if (ph > 160) return 1f;
        return 1f - 0.92f * (float) Math.sin(Math.PI * ph / 160.0);
    }

    private static void eyeVertex(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float z, float u, float v, float a) {
        vc.addVertex(pose.pose(), x, y, z).setColor(1f, 1f, 1f, a).setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY).setLight(LightTexture.FULL_BRIGHT).setNormal(pose, 0f, 0f, -1f);
    }

    /**
     * Реалистичные глаза на лице: те же текстуры, что в сцене с кроватью. Вызывать внутри масштаба фигуры.
     */
    private static void drawFaceEyes(PoseStack ps, MultiBufferSource buffers, float t) {
        long ms = (long) (t * 50f);
        float gx = 0f, gy = 0f;
        RandomSource gr = RandomSource.create(ms / 1300L * 31L + 7L);
        if (gr.nextInt(10) >= 7) {
            gx = (gr.nextFloat() - 0.5f) * 0.34f;
            gy = (gr.nextFloat() - 0.5f) * 0.12f;
        }
        gx += (float) Math.sin(ms / 410.0) * 0.02f;

        ps.pushPose();
        ps.mulPose(Axis.YP.rotationDegrees(180f - ghost.getYRot()));
        ps.translate(0, ObserverTuning.FACE_PIVOT_Y, 0);
        ps.mulPose(Axis.XP.rotationDegrees(-ghost.getXRot()));
        PoseStack.Pose pose = ps.last();
        for (int layer = 0; layer < 3; layer++) {
            for (int s = 0; s < 2; s++) {
                boolean left = s == 0;
                float sy = eyeBlink(ms, left ? 3700 : 4300, left ? 0 : 900);
                float size = ObserverTuning.FACE_EYE_W * (left ? 1f : 0.94f);
                float cx = (left ? 1f : -1f) * ObserverTuning.FACE_EYE_DX;
                float cy = ObserverTuning.FACE_EYE_Y - ObserverTuning.FACE_PIVOT_Y - (left ? 0f : 0.01f);
                float hw = size / 2f;
                float hh = size * 0.675f / 2f * sy;
                float a = layer == 2 ? 1f : (left ? 1f : 0.85f);
                if (layer == 1) {
                    cx += gx * size;
                    cy += gy * size * sy;
                    hw = size * 0.22f;
                    hh = size * 0.2184f * sy;
                }
                float z = -(ObserverTuning.FACE_Z + layer * 0.003f);
                VertexConsumer vc = buffers.getBuffer(RenderType.entityTranslucentEmissive(EYE_TEX[layer][s]));
                eyeVertex(vc, pose, cx + hw, cy - hh, z, 0f, 1f, a);
                eyeVertex(vc, pose, cx - hw, cy - hh, z, 1f, 1f, a);
                eyeVertex(vc, pose, cx - hw, cy + hh, z, 1f, 0f, a);
                eyeVertex(vc, pose, cx + hw, cy + hh, z, 0f, 0f, a);
            }
        }
        ps.popPose();
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        despawn();
        ticksUntilSpawn = -1;
        debugForce = false;
        wasAway = false;
        ObserverState.reset();
        deferSpawn = false;
    }

    // ------------------------------------------------------------------
    // Отладка: /hypersomnia_observer spawn | off
    // ------------------------------------------------------------------
    @SubscribeEvent
    public static void onRegisterClientCommands(RegisterClientCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("hypersomnia_observer")
                .then(Commands.literal("spawn").executes(ctx -> {
                    debugForce = true;
                    despawn();
                    ticksUntilSpawn = 1;
                    ctx.getSource().sendSuccess(() -> Component.literal("Observer: forced on"), false);
                    return 1;
                }))
                .then(Commands.literal("off").executes(ctx -> {
                    debugForce = false;
                    despawn();
                    ticksUntilSpawn = -1;
                    ctx.getSource().sendSuccess(() -> Component.literal("Observer: back to normal rules"), false);
                    return 1;
                }))
                .then(Commands.literal("scare").executes(ctx -> {
                    ObserverScare.reset();
                    ObserverScare.trigger(Math.max(2, ObserverState.stage()));
                    return 1;
                }))
                .then(Commands.literal("still")
                        .executes(ctx -> {
                            boolean ok = ImmobilityClient.triggerNow();
                            ctx.getSource().sendSuccess(() -> Component.literal(
                                    ok ? "Immobility: triggered" : "Immobility: not started (busy / paused)"), false);
                            return 1;
                        })
                        .then(Commands.literal("reset").executes(ctx -> {
                            ImmobilityClient.resetAll();
                            ctx.getSource().sendSuccess(() -> Component.literal("Immobility: counter and cooldown reset"), false);
                            return 1;
                        })))
                .then(Commands.literal("glitch")
                        .executes(ctx -> {
                            GlitchClient.triggerNow();
                            ctx.getSource().sendSuccess(() -> Component.literal("Glitch: triggered"), false);
                            return 1;
                        })
                        .then(Commands.literal("reset").executes(ctx -> {
                            GlitchClient.resetCooldown();
                            ctx.getSource().sendSuccess(() -> Component.literal("Glitch: cooldown reset"), false);
                            return 1;
                        })))
                .then(Commands.literal("breath").executes(ctx -> {
                    BreathClient.triggerNow();
                    ctx.getSource().sendSuccess(() -> Component.literal("Breath: burst"), false);
                    return 1;
                }))
                .then(Commands.literal("director")
                        .executes(ctx -> {
                            ctx.getSource().sendSuccess(() -> Component.literal(ObserverDirector.status()), false);
                            return 1;
                        })
                        .then(Commands.literal("fill").executes(ctx -> {
                            ObserverDirector.fill();
                            ctx.getSource().sendSuccess(() -> Component.literal("Director: budget full, silence off"), false);
                            return 1;
                        }))));
    }
}
