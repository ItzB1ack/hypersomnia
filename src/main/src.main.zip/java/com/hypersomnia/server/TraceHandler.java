package com.hypersomnia.server;

import com.hypersomnia.Hypersomnia;
import com.hypersomnia.ModAttachments;
import com.hypersomnia.ObserverProgressData;
import com.hypersomnia.ObserverTuning;
import com.hypersomnia.network.TraceSyncPayload;
import com.hypersomnia.trace.TraceAttachments;
import com.hypersomnia.trace.TraceData;
import com.hypersomnia.trace.TraceTuning;
import com.hypersomnia.trace.TraceType;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/** Расставляет следы осколка после пробуждения (только Верхний мир, только для этого игрока) и синхронизирует их. */
@EventBusSubscriber(modid = Hypersomnia.MOD_ID)
public final class TraceHandler {
    private TraceHandler() {}

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) send(player, player.getData(TraceAttachments.TRACES));
    }

    /** Вызывать из DreamTransition.exit() после возврата игрока. origin = где он уснул. */
    public static void onWake(ServerPlayer player, ServerLevel level, BlockPos origin) {
        place(player, level, origin, false);
    }

    /** force = отладка: без стадии и шанса, любые виды. Возвращает, сколько следов добавлено. */
    public static int place(ServerPlayer player, ServerLevel level, BlockPos origin, boolean force) {
        if (level.dimension() != Level.OVERWORLD) return 0;
        ObserverProgressData prog = player.getData(ModAttachments.OBSERVER);
        int stage = ObserverTuning.stage(prog.getDays(), prog.memoriesCount());
        RandomSource r = player.getRandom();
        if (!force) {
            if (stage < TraceTuning.MIN_STAGE || r.nextFloat() >= TraceTuning.WAKE_CHANCE) return 0;
        }
        TraceData data = player.getData(TraceAttachments.TRACES);
        int want = TraceTuning.PER_WAKE_MIN + r.nextInt(TraceTuning.PER_WAKE_MAX - TraceTuning.PER_WAKE_MIN + 1);
        int added = 0;
        for (int n = 0; n < want; n++) {
            TraceType type = pick(r, force ? Integer.MAX_VALUE : stage);
            if (type == null) break;
            TraceData.Entry e = tryPlace(level, data, origin, type, r);
            if (e != null) {
                data.add(e);
                added++;
            }
        }
        if (added > 0) send(player, data);
        return added;
    }

    public static void clear(ServerPlayer player) {
        TraceData data = player.getData(TraceAttachments.TRACES);
        data.clear();
        send(player, data);
    }

    public static void send(ServerPlayer player, TraceData data) {
        data.consumeDirty();
        PacketDistributor.sendToPlayer(player, new TraceSyncPayload(data.flat()));
    }

    private static TraceType pick(RandomSource r, int stage) {
        int total = 0;
        for (TraceType t : TraceType.values()) if (stage >= t.minStage) total += t.weight;
        if (total <= 0) return null;
        int roll = r.nextInt(total);
        for (TraceType t : TraceType.values()) {
            if (stage < t.minStage) continue;
            roll -= t.weight;
            if (roll < 0) return t;
        }
        return null;
    }

    private static TraceData.Entry tryPlace(ServerLevel level, TraceData data, BlockPos origin, TraceType type, RandomSource r) {
        for (int i = 0; i < TraceTuning.ATTEMPTS; i++) {
            boolean indoorOnly = i < TraceTuning.ATTEMPTS / 2;
            int x = origin.getX() + r.nextInt(TraceTuning.RADIUS * 2 + 1) - TraceTuning.RADIUS;
            int z = origin.getZ() + r.nextInt(TraceTuning.RADIUS * 2 + 1) - TraceTuning.RADIUS;
            Direction wallDir = Direction.Plane.HORIZONTAL.getRandomDirection(r);
            for (int y = origin.getY() + 3; y >= origin.getY() - 4; y--) {
                BlockPos p = new BlockPos(x, y, z);
                Direction face;
                if (type.kind == TraceType.Kind.WALL) {
                    face = wallDir;
                    BlockPos air = p.relative(face);
                    if (!level.getBlockState(p).isFaceSturdy(level, p, face) || !level.isEmptyBlock(air)) continue;
                    // стена комнаты: пол в пределах двух блоков под местом
                    if (!level.getBlockState(air.below()).isFaceSturdy(level, air.below(), Direction.UP)
                            && !level.getBlockState(air.below(2)).isFaceSturdy(level, air.below(2), Direction.UP)) continue;
                } else {
                    face = Direction.UP;
                    if (!level.getBlockState(p).isFaceSturdy(level, p, Direction.UP)) continue;
                }
                BlockPos air = p.relative(face);
                if (!level.isEmptyBlock(air) || !level.getFluidState(air).isEmpty()) continue;
                if (indoorOnly && level.canSeeSky(air)) continue;
                if (data.has(p, face.ordinal())) continue;
                return new TraceData.Entry(type.ordinal(), p, face.ordinal(), r.nextInt(type.variants), r.nextInt(8));
            }
        }
        return null;
    }
}