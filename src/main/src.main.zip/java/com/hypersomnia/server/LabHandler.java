package com.hypersomnia.server;

import com.hypersomnia.Hypersomnia;
import com.hypersomnia.lab.LabLift;
import com.hypersomnia.lab.LabLocks;
import com.hypersomnia.lab.LabSavedData;
import com.hypersomnia.lab.LabTuning;
import com.hypersomnia.network.LabLiftPayload;
import com.hypersomnia.network.LabLiftSelectPayload;
import com.hypersomnia.network.LabLockCodePayload;
import com.hypersomnia.network.LabLockPayload;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** ПКМ по табличкам лаборатории: панель лифта и замки. Сервер проверяет все ответы клиента. */
@EventBusSubscriber(modid = Hypersomnia.MOD_ID)
public final class LabHandler {
    private LabHandler() {}

    @SubscribeEvent
    public static void onUse(PlayerInteractEvent.RightClickBlock event) {
        if (event.getHand() != InteractionHand.MAIN_HAND) return;
        if (!(event.getEntity() instanceof ServerPlayer player) || !(event.getLevel() instanceof ServerLevel level)) return;
        LabSavedData d = LabSavedData.get(level);
        if (!d.built) return;
        Integer v = d.inter.get(event.getPos().asLong());
        if (v == null) return;
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        int kind = v / 1000, id = v % 1000;
        if (kind == LabSavedData.KIND_LIFT) {
            int cur = LabLift.stopOf(player, d);
            if (cur < 0) return;
            int enabled = LabLift.enabledMask(d) & ~(1 << cur);
            PacketDistributor.sendToPlayer(player, new LabLiftPayload(cur, enabled, d.builtMask));
        } else if (kind == LabSavedData.KIND_LOCK) {
            if (d.isLockOpen(id)) {
                player.displayClientMessage(Component.translatable("hypersomnia.lab.lock.open"), true);
                return;
            }
            PacketDistributor.sendToPlayer(player, new LabLockPayload(id, LabLockPayload.OPEN));
        }
    }

    public static void handleLockCode(LabLockCodePayload pl, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (!(ctx.player() instanceof ServerPlayer player)) return;
            ServerLevel level = player.serverLevel();
            LabSavedData d = LabSavedData.get(level);
            if (!d.built || d.isLockOpen(pl.lock())) return;
            BlockPos pos = d.lockPos(pl.lock());
            if (pos == null) return;
            if (player.blockPosition().distSqr(pos) > LabTuning.KEYPAD_MAX_DIST * LabTuning.KEYPAD_MAX_DIST) return;
            boolean ok = LabLocks.check(d, pl.lock(), pl.code());
            if (ok) LabLocks.grant(level, d, pl.lock());
            else level.playSound(null, pos, SoundEvents.IRON_TRAPDOOR_CLOSE, SoundSource.BLOCKS, 1.0f, 0.5f);
            PacketDistributor.sendToPlayer(player,
                    new LabLockPayload(pl.lock(), ok ? LabLockPayload.GRANTED : LabLockPayload.DENIED));
        });
    }

    public static void handleLiftSelect(LabLiftSelectPayload pl, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (!(ctx.player() instanceof ServerPlayer player)) return;
            LabLift.request(player, pl.target());
        });
    }
}
