package com.hypersomnia.server;

import com.hypersomnia.Hypersomnia;
import com.hypersomnia.ModAttachments;
import com.hypersomnia.ObserverProgressData;
import com.hypersomnia.ObserverTuning;
import com.hypersomnia.document.DocumentItem;
import com.hypersomnia.dream.DreamAttachments;
import com.hypersomnia.dream.DreamData;
import com.hypersomnia.dream.DreamTransition;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Container;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.decoration.HangingEntity;
import net.minecraft.world.entity.decoration.ItemFrame;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.AttackEntityEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/**
 * Выдача записок слоя 1. Бросок при входе в сон: стадия, шанс, способ и страница.
 * Кровать, контейнер и окно доставляются при пробуждении, инвентарь и мир снов сразу при входе.
 * Не вышло доставить: запасные способы кровать, затем инвентарь. Страница считается выданной только после доставки.
 */
@EventBusSubscriber(modid = Hypersomnia.MOD_ID)
public final class ObserverNotesHandler {
    private ObserverNotesHandler() {}

    /** Порядок совпадает с массивами NOTE_WAY_* в ObserverTuning. */
    public enum Way { BED, CONTAINER, WINDOW, INVENTORY, DREAM }

    /** Метка рамки-«наклейки» на окне: записку забирают и ЛКМ, и ПКМ, рамка не выпадает. */
    public static final String WINDOW_TAG = "hypersomnia_note";

    // ------------------------------------------------------------------
    // Бросок и выдача
    // ------------------------------------------------------------------

    /** Вызывать из DreamTransition.enter() после телепорта игрока в мир снов. */
    public static void onEnterDream(ServerPlayer player, ServerLevel dream) {
        ObserverProgressData data = player.getData(ModAttachments.OBSERVER);
        data.clearPending();
        int stage = ObserverTuning.stage(data.getDays(), data.memoriesCount());
        if (stage < ObserverTuning.NOTE_MIN_STAGE) return;
        if (player.getRandom().nextFloat() >= ObserverTuning.NOTE_CHANCE) return;
        int note = data.nextFreeNote(stage);
        if (note < 0) return;
        Way way = pickWay(player.getRandom(), stage);
        if (way == null) return;

        if (way == Way.INVENTORY || way == Way.DREAM) {
            ItemStack stack = DocumentItem.make(ObserverTuning.NOTE_PAGES[note]);
            if (deliver(player, dream, player.blockPosition(), way, stack)) {
                data.addNote(note);
                return;
            }
            way = Way.BED;
        }
        data.setPending(note, way.ordinal());
    }

    /** Вызывать из DreamTransition.exit() после возврата игрока в Верхний мир. */
    public static void onWake(ServerPlayer player, ServerLevel level) {
        ObserverProgressData data = player.getData(ModAttachments.OBSERVER);
        int note = data.getPendingNote();
        int wayIdx = data.getPendingWay();
        data.clearPending();
        if (note < 0 || note >= ObserverTuning.NOTE_PAGES.length || wayIdx < 0 || data.hasNote(note)) return;

        DreamData dream = player.getData(DreamAttachments.DREAM);
        BlockPos origin = BlockPos.containing(dream.getReturnX(), dream.getReturnY(), dream.getReturnZ());
        Way[] chain = {Way.values()[wayIdx], Way.BED, Way.INVENTORY};
        for (Way w : chain) {
            ItemStack stack = DocumentItem.make(ObserverTuning.NOTE_PAGES[note]);
            if (deliver(player, level, origin, w, stack)) {
                data.addNote(note);
                return;
            }
        }
    }

    /** Отладка (/hypersomnia_progress notes give <0-4>): первая страница выбранным способом вокруг игрока, без учёта прогресса. */
    public static boolean giveNow(ServerPlayer player, int wayIndex) {
        Way[] ways = Way.values();
        if (wayIndex < 0 || wayIndex >= ways.length) return false;
        ItemStack stack = DocumentItem.make(ObserverTuning.NOTE_PAGES[0]);
        return deliver(player, player.serverLevel(), player.blockPosition(), ways[wayIndex], stack);
    }

    private static Way pickWay(RandomSource r, int stage) {
        Way[] ways = Way.values();
        int total = 0;
        for (Way w : ways) {
            if (stage >= ObserverTuning.NOTE_WAY_MIN_STAGE[w.ordinal()]) total += ObserverTuning.NOTE_WAY_WEIGHT[w.ordinal()];
        }
        if (total <= 0) return null;
        int roll = r.nextInt(total);
        for (Way w : ways) {
            if (stage < ObserverTuning.NOTE_WAY_MIN_STAGE[w.ordinal()]) continue;
            roll -= ObserverTuning.NOTE_WAY_WEIGHT[w.ordinal()];
            if (roll < 0) return w;
        }
        return null;
    }

    private static boolean deliver(ServerPlayer player, ServerLevel level, BlockPos origin, Way way, ItemStack stack) {
        return switch (way) {
            case BED -> placeOnBed(level, origin, stack);
            case CONTAINER -> putInContainer(level, origin, stack);
            case WINDOW -> stickToWindow(level, origin, stack);
            case INVENTORY -> putInInventory(player, stack);
            case DREAM -> dropNearby(player, level, stack);
        };
    }

    // ------------------------------------------------------------------
    // Способы
    // ------------------------------------------------------------------

    /** На кровати, где игрок уснул. Подбор не сразу, чтобы он успел заметить лист. */
    private static boolean placeOnBed(ServerLevel level, BlockPos origin, ItemStack stack) {
        int r = ObserverTuning.NOTE_BED_RADIUS;
        BlockPos best = null;
        double bestD = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(origin.offset(-r, -1, -r), origin.offset(r, 1, r))) {
            if (!level.hasChunkAt(p) || !level.getBlockState(p).is(BlockTags.BEDS)) continue;
            double d = p.distSqr(origin);
            if (d < bestD) {
                bestD = d;
                best = p.immutable();
            }
        }
        if (best == null) return false;
        spawnItem(level, best.getX() + 0.5, best.getY() + 0.6, best.getZ() + 0.5, stack, ObserverTuning.NOTE_BED_PICKUP_DELAY);
        return true;
    }

    /** В свободный слот ближайшего сундука или бочки. */
    private static boolean putInContainer(ServerLevel level, BlockPos origin, ItemStack stack) {
        int r = ObserverTuning.NOTE_CONTAINER_RADIUS;
        Container best = null;
        int bestSlot = -1;
        double bestD = Double.MAX_VALUE;
        for (BlockPos p : BlockPos.betweenClosed(origin.offset(-r, -r, -r), origin.offset(r, r, r))) {
            if (!level.hasChunkAt(p)) continue;
            BlockEntity be = level.getBlockEntity(p);
            if (!(be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity)) continue;
            Container c = (Container) be;
            int slot = -1;
            for (int i = 0; i < c.getContainerSize(); i++) {
                if (c.getItem(i).isEmpty()) {
                    slot = i;
                    break;
                }
            }
            if (slot < 0) continue;
            double d = p.distSqr(origin);
            if (d < bestD) {
                bestD = d;
                best = c;
                bestSlot = slot;
            }
        }
        if (best == null) return false;
        best.setItem(bestSlot, stack);
        best.setChanged();
        return true;
    }

    /** Приклеена к стеклу изнутри: невидимая рамка с запиской. Внутри = клетка под крышей, снаружи = видно небо. */
    private static boolean stickToWindow(ServerLevel level, BlockPos origin, ItemStack stack) {
        int r = ObserverTuning.NOTE_WINDOW_RADIUS;
        BlockPos bestInner = null;
        Direction bestDir = null;
        double bestD = Double.MAX_VALUE;
        for (BlockPos g : BlockPos.betweenClosed(origin.offset(-r, -2, -r), origin.offset(r, 3, r))) {
            if (!level.hasChunkAt(g) || !level.getBlockState(g).is(BlockTags.IMPERMEABLE)) continue;
            for (Direction d : Direction.Plane.HORIZONTAL) {
                BlockPos inner = g.relative(d).immutable();
                BlockPos outer = g.relative(d.getOpposite()).immutable();
                if (!level.getBlockState(inner).isAir() || !level.getBlockState(outer).isAir()) continue;
                if (level.canSeeSky(inner) || !level.canSeeSky(outer)) continue;
                double dist = inner.distSqr(origin);
                if (dist < bestD) {
                    bestD = dist;
                    bestInner = inner;
                    bestDir = d;
                }
            }
        }
        if (bestInner == null) return false;
        if (!level.getEntitiesOfClass(HangingEntity.class, new AABB(bestInner)).isEmpty()) return false;

        ItemFrame frame = new ItemFrame(level, bestInner, bestDir);
        if (!frame.survives()) return false;
        frame.setItem(stack);
        frame.setInvisible(true);
        frame.addTag(WINDOW_TAG);
        level.addFreshEntity(frame);
        return true;
    }

    /** В свободный слот основного инвентаря (не хотбар): находит позже сам. */
    private static boolean putInInventory(ServerPlayer player, ItemStack stack) {
        Inventory inv = player.getInventory();
        for (int i = 9; i < 36; i++) {
            if (inv.getItem(i).isEmpty()) {
                inv.setItem(i, stack);
                return true;
            }
        }
        return false;
    }

    /** На земле рядом с игроком (в мире снов). */
    private static boolean dropNearby(ServerPlayer player, ServerLevel level, ItemStack stack) {
        RandomSource rnd = player.getRandom();
        double a = rnd.nextDouble() * Math.PI * 2.0;
        double dist = Mth.lerp(rnd.nextFloat(), ObserverTuning.NOTE_DREAM_DIST_MIN, ObserverTuning.NOTE_DREAM_DIST_MAX);
        BlockPos p = DreamTransition.findSafe(level, BlockPos.containing(
                player.getX() + Math.cos(a) * dist, player.getY(), player.getZ() + Math.sin(a) * dist));
        spawnItem(level, p.getX() + 0.5, p.getY() + 0.1, p.getZ() + 0.5, stack, ObserverTuning.NOTE_DREAM_PICKUP_DELAY);
        return true;
    }

    private static void spawnItem(ServerLevel level, double x, double y, double z, ItemStack stack, int pickupDelay) {
        ItemEntity e = new ItemEntity(level, x, y, z, stack);
        e.setDeltaMovement(Vec3.ZERO);
        e.setUnlimitedLifetime();
        e.setPickUpDelay(pickupDelay);
        level.addFreshEntity(e);
    }

    // ------------------------------------------------------------------
    // Записка на окне: забирается ПКМ или ЛКМ, рамка исчезает без выпадения
    // ------------------------------------------------------------------

    @SubscribeEvent
    public static void onInteract(PlayerInteractEvent.EntityInteract event) {
        if (!(event.getTarget() instanceof ItemFrame frame) || !frame.getTags().contains(WINDOW_TAG)) return;
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        if (!event.getLevel().isClientSide) take(event.getEntity(), frame);
    }

    @SubscribeEvent
    public static void onAttack(AttackEntityEvent event) {
        if (!(event.getTarget() instanceof ItemFrame frame) || !frame.getTags().contains(WINDOW_TAG)) return;
        event.setCanceled(true);
        if (!event.getEntity().level().isClientSide) take(event.getEntity(), frame);
    }

    private static void take(Player player, ItemFrame frame) {
        if (frame.isRemoved()) return;
        ItemStack stack = frame.getItem().copy();
        frame.discard();
        if (!stack.isEmpty()) player.getInventory().placeItemBackInInventory(stack);
    }
}