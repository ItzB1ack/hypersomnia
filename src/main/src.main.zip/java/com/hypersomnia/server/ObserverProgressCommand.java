package com.hypersomnia.server;

import com.hypersomnia.Hypersomnia;
import com.hypersomnia.ModAttachments;
import com.hypersomnia.ObserverProgressData;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

/** Отладка: /hypersomnia_progress days <n> | memories <0-7> | status */
@EventBusSubscriber(modid = Hypersomnia.MOD_ID)
public final class ObserverProgressCommand {
    private ObserverProgressCommand() {}

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("hypersomnia_progress")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("days").then(Commands.argument("n", IntegerArgumentType.integer(0, 1000))
                        .executes(ctx -> {
                            ServerPlayer p = ctx.getSource().getPlayerOrException();
                            p.getData(ModAttachments.OBSERVER).setDays(IntegerArgumentType.getInteger(ctx, "n"));
                            return status(ctx.getSource(), p);
                        })))
                .then(Commands.literal("memories").then(Commands.argument("n", IntegerArgumentType.integer(0, 7))
                        .executes(ctx -> {
                            ServerPlayer p = ctx.getSource().getPlayerOrException();
                            p.getData(ModAttachments.OBSERVER).setMemoriesCount(IntegerArgumentType.getInteger(ctx, "n"));
                            return status(ctx.getSource(), p);
                        })))
                .then(Commands.literal("notes")
                        .then(Commands.literal("reset").executes(ctx -> {
                            ServerPlayer p = ctx.getSource().getPlayerOrException();
                            p.getData(ModAttachments.OBSERVER).resetNotes();
                            return status(ctx.getSource(), p);
                        }))
                        .then(Commands.literal("give").then(Commands.argument("way", IntegerArgumentType.integer(0, 4))
                                .executes(ctx -> {
                                    ServerPlayer p = ctx.getSource().getPlayerOrException();
                                    boolean ok = com.hypersomnia.server.ObserverNotesHandler.giveNow(p, IntegerArgumentType.getInteger(ctx, "way"));
                                    ctx.getSource().sendSuccess(() -> Component.literal("note delivered=" + ok
                                            + " (0 bed, 1 container, 2 window, 3 inventory, 4 dream)"), false);
                                    return ok ? 1 : 0;
                                }))))
                .then(Commands.literal("drawings").then(Commands.argument("i", IntegerArgumentType.integer(0, 5))
                        .executes(ctx -> {
                            ServerPlayer p = ctx.getSource().getPlayerOrException();
                            p.getInventory().placeItemBackInInventory(com.hypersomnia.document.DocumentItem.make(
                                    com.hypersomnia.document.DrawingTuning.idOf(IntegerArgumentType.getInteger(ctx, "i"))));
                            return 1;
                        })))
                .then(Commands.literal("memory").then(Commands.argument("i", IntegerArgumentType.integer(1, 7))
                        .executes(ctx -> {
                            ServerPlayer p = ctx.getSource().getPlayerOrException();
                            p.getInventory().placeItemBackInInventory(com.hypersomnia.document.DocumentItem.make(
                                    com.hypersomnia.document.MemoryTuning.IDS[IntegerArgumentType.getInteger(ctx, "i") - 1]));
                            return 1;
                        })))
                .then(Commands.literal("status").executes(ctx ->
                        status(ctx.getSource(), ctx.getSource().getPlayerOrException()))));
    }

    private static int status(net.minecraft.commands.CommandSourceStack src, ServerPlayer p) {
        ObserverProgressData d = p.getData(ModAttachments.OBSERVER);
        int stage = com.hypersomnia.ObserverTuning.stage(d.getDays(), d.memoriesCount());
        src.sendSuccess(() -> Component.literal("days=" + d.getDays() + " memories=" + d.memoriesCount()
                + " stage=" + stage + " notes=" + d.notesCount()
                + " drawings=" + d.drawingsCount() + (d.hasBlank() ? "+blank" : "")), false);
        return 1;
    }
}