package com.hypersomnia;

/** Числа баланса наблюдателя. Всё в одном месте, как FatigueTuning. */
public final class ObserverTuning {
    private ObserverTuning() {}

    // ---- Когда может появляться ----
    /** Доля усталости, с которой наблюдатель начинает появляться (пока безумие = 0). */
    public static final float START_RATIO = 0.30f;
    /** То же, но после первого принудительного сна (безумие > 0). */
    public static final float START_RATIO_AFTER_MADNESS = 0.15f;
    /** Безумие, при котором «давление» от него достигает максимума. */
    public static final int MADNESS_CAP = 5;
    /** Максимальная освещённость места появления (0..15). Ночью/в пещерах/в тени. */
    public static final int MAX_LIGHT = 9;

    // ---- Частота (тики): при давлении 0 -> при давлении 1 ----
    public static final int SPAWN_INTERVAL_MAX = 6000;   // 5 минут
    public static final int SPAWN_INTERVAL_MIN = 1200;   // 1 минута

    // ---- Где появляется ----
    /** Появляется ВНЕ поля зрения: на столько градусов за краем поля зрения (плюс разброс). Игрок замечает его, повернувшись. */
    public static final float SPAWN_OUTSIDE_VIEW_MARGIN = 12f;
    public static final float SPAWN_ANGLE_SPREAD = 40f;
    public static final float SPAWN_DISTANCE_MIN = 18f;
    public static final float SPAWN_DISTANCE_MAX = 32f;

    // ---- Правила реального мира: исчезает при взгляде ----
    /** Доля реального поля зрения (FOV и размер окна), внутри которой считается, что игрок его видит. 1 = до самого края экрана. */
    public static final float VIEW_MARGIN = 0.95f;
    /** Сколько тиков нужно смотреть, чтобы он исчез: база + за каждую единицу безумия, не больше максимума. */
    public static final int GAZE_TICKS_BASE = 3;
    public static final int GAZE_TICKS_PER_MADNESS = 3;
    public static final int GAZE_TICKS_MAX = 30;
    /** Исчезает, если игрок подошёл ближе / ушёл дальше. */
    public static final double NEAR_VANISH = 6.0;
    public static final double FAR_VANISH = 56.0;
    /** Время жизни (тики): база + за безумие. */
    public static final int LIFETIME_BASE = 600;
    public static final int LIFETIME_PER_MADNESS = 60;
    public static final int LIFETIME_MAX = 1400;

    // ---- Частицы при исчезновении ----
    public static final int VANISH_DUST_COUNT = 60;
    public static final int VANISH_INK_COUNT = 20;

    // ---- Шаги ближе, пока игрок не смотрит (только реальный мир) ----
    // Шаги делаются только пока он вне поля зрения.
    public static final int STEP_COOLDOWN_MIN = 60;
    public static final int STEP_COOLDOWN_MAX = 120;
    public static final float STEP_DISTANCE_MIN = 1.5f;
    public static final float STEP_DISTANCE_MAX = 3.0f;
    /** Ближе этой дистанции не подходит: база, минус за безумие, но не меньше пола. */
    public static final float APPROACH_LIMIT_BASE = 14f;
    public static final float APPROACH_LIMIT_PER_MADNESS = 1.5f;
    public static final float APPROACH_LIMIT_FLOOR = 8f;

    // ---- Правила мира снов: НЕ исчезает, а подходит, пока смотришь ----
    public static final double DREAM_APPROACH_SPEED = 0.06;       // блоков за тик
    public static final double DREAM_APPROACH_PER_MADNESS = 0.01;
    public static final double DREAM_STOP_DISTANCE = 3.0;

    // ---- Стадии осколка: очки = дни + MEMORY_POINTS * воспоминания ----
    public static final int TICKS_PER_DAY = 24000;
    public static final int MEMORY_POINTS = 2;
    /** Очки, с которых начинаются стадии 1..5. */
    public static final int[] STAGE_POINTS = {5, 10, 16, 22, 28};
    /** Стадия 5 требует хотя бы столько воспоминаний, иначе остаётся 4. */
    public static final int STAGE5_MIN_MEMORIES = 4;

    public static int stage(int days, int memories) {
        int points = days + MEMORY_POINTS * memories;
        int s = 0;
        for (int i = 0; i < STAGE_POINTS.length; i++) if (points >= STAGE_POINTS[i]) s = i + 1;
        if (s >= 5 && memories < STAGE5_MIN_MEMORIES) s = 4;
        return s;
    }

    // ---- Мир снов по стадиям ----
    /** С какой стадии он приближается (до неё стоит далеко и со временем исчезает). */
    public static final int DREAM_APPROACH_MIN_STAGE = 4;
    /** С какой стадии замечание запускает кадр-сюрприз; длительность (тики) и кулдаун (= длина сна). */
    public static final int SCARE_MIN_STAGE = 2;
    public static final int SCARE_TICKS = 8;
    public static final int SCARE_COOLDOWN_TICKS = 100;

    // ---- Осколок у кровати (Верхний мир, пока игрок засыпает) ----
    public static final int BED_WATCH_MIN_STAGE = 2;
    /** На каком тике лежания он может появиться (после тика сцены TRIGGER_TICK=30, чтобы не мешать ей). */
    public static final int BED_WATCH_DELAY_TICKS = 45;
    /** Шанс за одно засыпание: база + за каждую стадию выше минимальной. */
    public static final float BED_WATCH_CHANCE_BASE = 0.25f;
    public static final float BED_WATCH_CHANCE_PER_STAGE = 0.10f;
    public static final float BED_WATCH_DISTANCE_MIN = 2.6f;
    public static final float BED_WATCH_DISTANCE_MAX = 3.4f;
    /** Медленно подкрадывается к кровати (блоков за тик), ближе этой дистанции не идёт. */
    public static final double BED_WATCH_CREEP_SPEED = 0.04;
    public static final double BED_WATCH_STOP_DISTANCE = 1.8;
    /** Разброс от оси кровати (градусы в обе стороны): узкий, чтобы он был в центре кадра. */
    public static final float BED_WATCH_SPREAD_DEG = 12f;
    /** Минимальная освещённость его модели (0..15), чтобы силуэт читался в темноте. */
    public static final int BED_WATCH_MIN_LIGHT = 7;

    // ---- Записки слоя 1 (ObserverNotesHandler) ----
    /**     /** Id страниц из DocumentDefs, выдаются по порядку, каждая один раз. 3-4 = половинки «Двух сторон» (слой 2). */
    public static final String[] NOTE_PAGES = {"note_l1_0", "note_l1_1", "note_l1_2", "note_l2_a", "note_l2_b", "note_l3"};
    /** Минимальная стадия для каждой страницы (по индексу NOTE_PAGES). */
    public static final int[] NOTE_PAGE_MIN_STAGE = {3, 3, 3, 4, 4, 5};
    public static final int NOTE_MIN_STAGE = 3;
    /** Шанс записки за один сон. */
    public static final float NOTE_CHANCE = 0.5f;
    /** Порядок как в ObserverNotesHandler.Way: BED, CONTAINER, WINDOW, INVENTORY, DREAM. */
    public static final int[] NOTE_WAY_MIN_STAGE = {3, 3, 3, 4, 4};
    public static final int[] NOTE_WAY_WEIGHT = {3, 2, 2, 2, 2};
    public static final int NOTE_BED_RADIUS = 3;
    public static final int NOTE_CONTAINER_RADIUS = 8;
    public static final int NOTE_WINDOW_RADIUS = 10;
    /** Записка на кровати: сколько тиков её нельзя подобрать, чтобы игрок успел её увидеть. */
    public static final int NOTE_BED_PICKUP_DELAY = 200;
    public static final int NOTE_DREAM_PICKUP_DELAY = 20;
    public static final float NOTE_DREAM_DIST_MIN = 4f;
    public static final float NOTE_DREAM_DIST_MAX = 8f;

    // ---- Образ осколка: тёмная масса с пропорциями игрока ----
    public static final float GHOST_SCALE_XZ = 1.15f;
    public static final float GHOST_SCALE_Y = 1.4f;
    /** «Плывущие края»: амплитуда и скорость (рад/тик) пульсации ширины. */
    public static final float GHOST_WOBBLE = 0.05f;
    public static final float GHOST_WOBBLE_SPEED = 0.13f;
    /** Эхо: разреженная копия, дрейфует вбок на столько блоков, скорость рад/тик. */
    public static final float ECHO_OFFSET = 0.22f;
    public static final float ECHO_SPEED = 0.05f;
    /** Человеческие глаза видны, если ближе этой дистанции (в мире снов всегда). */
    public static final double EYES_DISTANCE = 9.0;
    /** Глаза на лице (блоки, до масштаба фигуры): ширина, разнос, ось поворота головы, высота глаз, вынос перед лицом. */
    public static final float FACE_EYE_W = 0.18f;
    public static final float FACE_EYE_DX = 0.12f;
    public static final float FACE_PIVOT_Y = 1.41f;
    public static final float FACE_EYE_Y = 1.62f;
    public static final float FACE_Z = 0.24f;

    // ---- Дверь (стадия 4): звук «открыл-закрыл» за спиной, дверь в мире не меняется ----
    public static final int DOOR_MIN_STAGE = 4;
    /** Раз в сколько тиков бросок и шанс на бросок (при 200 и 0.03 в среднем раз в ~5 минут). */
    public static final int DOOR_CHECK_TICKS = 200;
    public static final float DOOR_CHANCE = 0.03f;
    public static final int DOOR_RADIUS = 10;
    public static final double DOOR_MIN_DIST = 4.0;
    /** Дверь не берём, если она в передней полусфере взгляда (косинус угла выше этого значения). */
    public static final double DOOR_MAX_LOOK_DOT = 0.3;
    /** Серия обрывается, если игрок посмотрел на дверь (косинус угла выше этого значения, 0.8 ≈ 37°). */
    public static final double DOOR_STOP_LOOK_DOT = 0.8;
    public static final int DOOR_CYCLES_MIN = 2;
    public static final int DOOR_CYCLES_MAX = 6;
    public static final int DOOR_OPEN_GAP_MIN = 8;
    public static final int DOOR_OPEN_GAP_MAX = 20;
    public static final int DOOR_CLOSE_GAP_MIN = 12;
    public static final int DOOR_CLOSE_GAP_MAX = 30;
    public static final float DOOR_VOLUME = 0.7f;

    // ---- Режиссёр (client/ObserverDirector): бюджет страха, один эпизод за раз, тишина ----
    public static final float DIRECTOR_BUDGET_CAP = 100f;
    public static final float DIRECTOR_BUDGET_START = 60f;
    /** Прирост бюджета за тик: база + давление (0..1) * множитель + за каждую стадию. */
    public static final float DIRECTOR_REGEN_BASE = 0.006f;
    public static final float DIRECTOR_REGEN_PER_PRESSURE = 0.012f;
    public static final float DIRECTOR_REGEN_PER_STAGE = 0.002f;
    /** Цена эпизода и кулдаун вида после его конца (тики). Порядок: GHOST, DOOR, SCARE. */
    public static final float[] DIRECTOR_COST = {35f, 50f, 40f};
    public static final int[] DIRECTOR_KIND_COOLDOWN = {1200, 6000, 2400};
    /** Тишина после любого эпизода, после пробуждения и после входа в игру (тики). */
    public static final int DIRECTOR_SILENCE_AFTER = 600;
    public static final int DIRECTOR_SILENCE_AFTER_WAKE = 1200;
    public static final int DIRECTOR_SILENCE_AT_START = 1200;

    // ---- Неподвижность (ImmobilityClient): 20 с без ввода -> тишина, шаг, силуэт на периферии ----
    /** Тики без движения/поворота/действий, после которых срабатывает эпизод. */
    public static final int STILL_TICKS = 400;
    /** Кулдаун между эпизодами (тики). */
    public static final int STILL_COOLDOWN = 4800;
    /** Длительность полной тишины в начале эпизода (тики). */
    public static final int STILL_SILENCE_TICKS = 40;
    /** Пауза после шага до появления силуэта (тики). */
    public static final int STILL_SPAWN_DELAY = 5;
    /** Сколько тиков силуэт стоит на периферии и не исчезает, даже если игрок смотрит. */
    public static final int STILL_VISIBLE_TICKS = 60;

    // ---- Сбой экспозиции (GlitchClient/GlitchOverlay): короткий сбой картинки и звука ----
    public static final int GLITCH_MIN_STAGE = 1;
    public static final int GLITCH_COOLDOWN_MIN = 3600;
    public static final int GLITCH_COOLDOWN_MAX = 7200;
    public static final int GLITCH_TICKS_MIN = 6;
    public static final int GLITCH_TICKS_MAX = 10;

    // ---- Дыхание (BreathClient): пар изо рта ночью/на морозе ----
    /** Перерыв между выдохами (тики). 60-160 = 3-8 с, как у спокойного дыхания. */
    public static final int BREATH_INTERVAL_MIN = 60;
    public static final int BREATH_INTERVAL_MAX = 160;
    /** Базовая температура биома ниже этой = «мороз», пар виден и днём. */
    public static final float BREATH_COLD_TEMP = 0.15f;
    /** Высота (Y) выше которой всегда холодно. */
    public static final int BREATH_COLD_Y = 120;
    /** Сколько частиц в одном выдохе. */
    public static final int BREATH_PARTICLES = 3;
    /** Звук выдоха: громкость и питч. */
    public static final float BREATH_SOUND_VOLUME = 0.35f;
    public static final float BREATH_SOUND_PITCH = 1.00f;

    /** Разброс направления «сзади» (градусы): осколок встаёт там, где был шаг. */
    public static final float STILL_BEHIND_SPREAD_DEG = 15f;
    /** Дистанция спавна для эпизода неподвижности: ближе обычной, чтобы обернувшись он был рядом. */
    public static final float STILL_DISTANCE_MIN = 5f;
    public static final float STILL_DISTANCE_MAX = 12f;

    // ---- Укрытия при появлении (client/ObserverCover) ----
    /** Доля появлений в укрытии (за деревом или за стеклом); остальное в открытую, как раньше. */
    public static final float COVER_CHANCE = 0.85f;
    /** Из укрытий: доля попыток сначала искать окно (нет окна, тогда дерево). */
    public static final float COVER_WINDOW_SHARE = 0.4f;
    public static final int COVER_ATTEMPTS = 12;
    public static final int TREE_SEARCH_RADIUS = 3;
    /** Встаёт за ствол от игрока и вбок от центра ствола, так что виден край фигуры. */
    public static final float TREE_PEEK_BEHIND = 0.55f;
    public static final float TREE_PEEK_SIDE = 0.62f;
    public static final int WINDOW_RADIUS = 20;
    public static final float WINDOW_DIST_MIN = 8f;
    public static final float WINDOW_DIST_MAX = 20f;
    /** Насколько вплотную к стеклу он стоит (блоков). */
    public static final float WINDOW_GLASS_GAP = 0.15f;
    /** Из укрытия наблюдает дольше и исчезает от взгляда чуть позже. */
    public static final float COVER_LIFETIME_MULT = 1.6f;
    public static final int COVER_GAZE_TICKS_BONUS = 8;
}
