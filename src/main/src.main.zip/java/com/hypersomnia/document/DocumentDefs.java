package com.hypersomnia.document;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Описание страниц: список элементов. Тексты по-английски; ключи lang: hypersomnia.doc.<id>.<номер элемента>
 * (запасной текст зашит здесь), заголовок предмета: hypersomnia.doc.<id>.title. Без клиентских импортов.
 */
public final class DocumentDefs {
    private DocumentDefs() {}

    /** OFFICIAL: чистая лабораторная бумага. NOTE: мятая записка осколка. */
    public enum Style { OFFICIAL, NOTE, DRAWING }

    public interface El {}
    public record Head(String text) implements El {}
    public record Para(String text) implements El {}
    /** Зачёркнутая строка. */
    public record Strike(String text) implements El {}
    public record Stamp(String text) implements El {}
    /** Слой 1: на каждую букву ряд глаз, число глаз = номер буквы (A=1). Пробел = разрыв. */
    public record Letters(String text) implements El {}
    /** Шифр 3: бьющееся сердце и кардиограмма (низкий скачок = точка, высокий = тире). printed = false: только сердце, без печатной линии. */
    public record Morse(String text, boolean printed) implements El {
        public Morse(String text) { this(text, true); }
    }
    /** Слой 3: зрачки, символы U D L R. */
    public record Dirs(String dirs) implements El {}
    /** Шифр 1: текст из lang, слова между * помечены глазом; первые буквы помеченных слов дают слово. */
    public record Marked(String text) implements El {}
    /** Шифр 2: глазной алфавит (EyeAlphabet). Текст берётся из lang, поэтому на русском шифруется кириллицей. */
    public record Glyphs(String text) implements El {}
    /** Фрагмент ключа глазного алфавита: знаки для перечисленных букв (тоже из lang). */
    public record GlyphKey(String letters) implements El {}
    public record Gap() implements El {}

    /** Картинка на всю ширину страницы: textures/misc/<tex>.png, размер 176 x h. */
    public record Picture(String tex, int h) implements El {}

    /** Кромка листа: целая или рваная (половинка одного разорванного листа). */
    public static final int EDGE_NONE = 0;
    public static final int EDGE_RIGHT = 1;
    public static final int EDGE_LEFT = 2;

    /** edge: EDGE_NONE — обычный лист, EDGE_RIGHT/LEFT — половина листа с рваной кромкой. */
    public record Doc(String id, String title, Style style, List<El> els, int edge) {
        public Doc(String id, String title, Style style, List<El> els) {
            this(id, title, style, els, EDGE_NONE);
        }
    }

    private static final Map<String, Doc> DEFS = new LinkedHashMap<>();

    public static Doc get(String id) { return DEFS.get(id); }
    public static Collection<Doc> all() { return DEFS.values(); }

    /** Номер модели предмета = порядок add(...) + 1 (0 = запасной лист). Новые страницы только в конец, и строку в PAGES скрипта тоже. */
    public static int modelIndex(String id) {
        int i = 1;
        for (String k : DEFS.keySet()) {
            if (k.equals(id)) return i;
            i++;
        }
        return 0;
    }

    private static void add(Doc d) { DEFS.put(d.id(), d); }

    static {
        // Индексы элементов = номера ключей lang: hypersomnia.doc.<id>.<индекс>
        add(new Doc("morse_sample", "Observation Log 12-B", Style.OFFICIAL, List.of(
                new Head("CRADLE / FORM 12-B"),                                   // 0
                new Stamp("CLASSIFIED"),                                          // 1
                new Para("Subject 47. Pattern recorded during idle phase. Reference transmission below. Decoded: HELP."), // 2
                new Morse("HELP"),                                                // 3
                new Gap(),                                                        // 4
                new Para("Same transmission, alternate encoding."),               // 5
                new Glyphs("HELP"),                                               // 6: зацепка к глазному алфавиту
                new Gap(),                                                        // 7
                new Para("Key: see the diary."))));                              // 8

        // Слой 1 (стадия 3). [placeholder] подсказки к рисункам Nora, уточним при расстановке рисунков.
        add(new Doc("note_l1_0", "Page", Style.NOTE, List.of(
                new Para("Did I write this?"),                                    // 0
                new Marked("*Where* is she? *It* was here again. *Never* asleep, never. *Did* I close the door? *Once* more. *Waiting*."))));  // 1: WINDOW
        add(new Doc("note_l1_1", "Page", Style.NOTE, List.of(
                new Para("It was on the pillow again."),                          // 0
                new Glyphs("BEHIND THE DOOR"))));                                 // 1
        add(new Doc("note_l1_2", "Page", Style.NOTE, List.of(
                new Strike("It is not mine."),                                    // 0
                new Para("It is mine."),                                          // 1
                new Glyphs("UNDER THE BED"))));

        // Рисунки Nora: drawing_0..3 готовы, drawing_4 ждёт описания. Картинка: textures/misc/<tex>.png, 176x132.
        add(new Doc("drawing_0", "Drawing", Style.DRAWING, List.of(new Picture("drawing_0", 132))));  // дом, окно закрашено
        add(new Doc("drawing_1", "Drawing", Style.DRAWING, List.of(
                new Picture("drawing_1", 132),                                    // 0: капсула
                new Para("daddy is sleeping"))));                                 // 1: подпись
        add(new Doc("drawing_2", "Drawing", Style.DRAWING, List.of(new Picture("drawing_2", 132))));  // солнце с закрытыми глазами
        add(new Doc("drawing_3", "Drawing", Style.DRAWING, List.of(new Picture("drawing_3", 132))));  // птица в открытой клетке
        add(new Doc("drawing_blank", "Unfinished Drawing", Style.DRAWING, List.of(new Picture("drawing_blank", 132))));// 2

        // Воспоминания 1-7 (MemoryTuning.IDS), затем не-воспоминания и рисунок 5. Порядок = PAGES в make_documents.py, новые только в конец.
        add(new Doc("mem_1_photo", "Photograph: Staff Event", Style.OFFICIAL, List.of(
                new Head("PHOTOGRAPH / ARCHIVE 0412"),                            // 0
                new Para("Image: two men at a staff event. E. Marsh, left. Director Halloran, right. Both smiling."), // 1
                new Para("Background: capsule 47. Placard: PROTOTYPE."),          // 2
                new Para("Date: before Contract C-47."),                          // 3
                new Head("REVERSE"),                                              // 4
                new Para("Elias, welcome to the team. - H."))));                  // 6
        add(new Doc("mem_2_discharge", "Discharge Summary: Nora Marsh", Style.OFFICIAL, List.of(
                new Head("DISCHARGE SUMMARY"),                                    // 0
                new Para("Patient: Marsh, Nora. Age: 8. Record No. 3341."),       // 1
                new Strike("Diagnosis: progressive cardiac failure, inoperable."), // 2
                new Stamp("CRADLE PRIORITY"),                                     // 3
                new Para("Attending: Dr. R. Lang. Date: 11 March. Recommendation: palliative care at home. Review in 30 days."), // 4
                new Gap(),                                                        // 5
                new Para("Patient's father requests transfer to experimental program. Approved."))));  // 6
        add(new Doc("mem_3_contract", "Contract C-47", Style.OFFICIAL, List.of(
                new Head("CONTRACT C-47"),                                        // 0
                new Para("Parties: Director Halloran (the Facility) and Dr. Elias Marsh (the Participant)."), // 1
                new Para("1. The Participant joins the Cradle programme as Subject 47."), // 2
                new Para("2. In return, the Facility grants Nora Marsh priority access to treatment."), // 3
                new Para("3. Sessions are scheduled at the Facility's discretion, usually at night."), // 4
                new Para("4. The Participant may not terminate a session early."), // 5
                new Para("5. Cognitive patterns recorded during the programme may be transferred to third parties."), // 6
                new Para("6. Records are stored for ten years."),                 // 7
                new Gap(),                                                        // 8
                new Para("Signed: E. Marsh   Halloran"),                          // 9
                new Stamp("APPROVED"))));                                         // 10
        add(new Doc("mem_4_session12", "Session 12", Style.OFFICIAL, List.of(
                new Head("SESSION 12 / AUDIO LOG"),                               // 0
                new Stamp("TRANSCRIPT"),                                          // 1
                new Para("Timecode 03:12. Speaker: E. Marsh. Condition: calm, fatigued."), // 2
                new Para("She liked it when I stayed up. She said the night shift was our secret. [NAME REDACTED] used to wait for me by the window."), // 3
                new Para("If this works, she gets more time. That is the whole calculation."), // 4
                new Para("I told [NAME REDACTED] I would be there when she woke. I was. I was always there."))));  // 5
        add(new Doc("mem_5_memo", "Report: Anomaly 47-A", Style.OFFICIAL, List.of(
                new Head("REPORT / DR. H. VOSS"),                                 // 0
                new Para("Anomaly 47-A persists."),                               // 1
                new Para("No sensory input from outside the recording. It cannot be reached. It can only reach."), // 2
                new Para("Observed: the entity writes in the subject's hand and repeats a single question. I heard it from the corridor, with the recording off."), // 3
                new Para("I do not know what this means. Logged as fact."))));    // 4
        add(new Doc("mem_6_protocol", "Incident Protocol 47", Style.OFFICIAL, List.of(
                new Head("INCIDENT PROTOCOL 47"),                                 // 0
                new Stamp("RESTRICTED"),                                          // 1
                new Para("02:41 - subject 47 in session."),                       // 2
                new Para("03:07 - Nora Marsh, cardiac arrest."),                  // 3
                new Para("03:12 - pronounced dead."),                             // 4
                new Para("03:13 - session 47 continues."),                        // 5
                new Para("Subject sedated deeper per Director's order."))));      // 6
        add(new Doc("mem_7_log", "Operator's Last Log", Style.OFFICIAL, List.of(
                new Head("OPERATOR / LAST LOG"),                                  // 0
                new Stamp("TRANSCRIPT"),                                          // 1
                new Para("No name needed. Recording."),                           // 2
                new Para("The girl would have died either way. I saw her numbers an hour before. Nothing in that room could have changed them."), // 3
                new Para("He could not wake. I ran the sequence four times. The Director ordered the sedation deeper and stood behind me until it was done."), // 4
                new Para("He couldn't have saved her. Nobody could. But he doesn't know that yet."), // 5
                new Para("If it can hear this: it was not his fault. This box is all I could save. Keep the lights on."))));  // 6

        // Не воспоминания: пропуск (оборот = ключ глазного алфавита), правка Voss, рисунок 5
        add(new Doc("employee_pass", "Employee Pass: E. Marsh", Style.OFFICIAL, List.of(
                new Head("CRADLE RESEARCH FACILITY"),                             // 0
                new Stamp("STAFF"),                                               // 1
                new Para("Name: Marsh, Elias. Dr."),                              // 2
                new Para("Position: neurophysiologist. Co-author, Cradle protocol. Clearance: level 4."), // 3
                new Gap(),                                                        // 4
                new Head("REVERSE"),                                              // 5
                new Para("Key: filed separately. See the diary."))));              // 6
        add(new Doc("voss_note", "Correction", Style.OFFICIAL, List.of(
                new Strike("Anomaly 47-A"),                                       // 0
                new Para("Fragment"))));                                          // 1
        add(new Doc("drawing_4", "Drawing", Style.DRAWING, List.of(new Picture("drawing_4", 132))));  // два папы, зайчик

        // «Две стороны» (слой 2): две половинки одного листа. Текст разрезан посередине:
        // каждая строка левой половины продолжается на правой.
        add(new Doc("note_l2_a", "Left Half", Style.NOTE, List.of(
                new Para("it starts at th"),                                      // строка 1: «...three. again.»
                new Para("the knocking ag"),                                      // строка 2: «...ain. it waits.»
                new Para("i went downstai"),                                      // строка 3: «...rs. the door.»
                new Para("the handle was "),                                      // строка 4: «...warm. it knew.»
                new Para("the far door rea"),                                     // строка 5: «...ds backwards.»
                new Para("do not answer i")), EDGE_RIGHT));                       // строка 5: «...t. - e.»
        add(new Doc("note_l2_b", "Right Half", Style.NOTE, List.of(
                new Para("ree. again."),                                          // 1
                new Para("ain. it waits."),                                       // 2
                new Para("rs. the door."),                                        // 3
                new Para("warm. it knew."),                                       // 4
                new Para("ds backwards."),                                        // 5
                new Para("t. - e.")), EDGE_LEFT));                                // 5

        // «Куда смотрят» (слой 3, мир снов): план зала сеансов, посты читаются по номерам; направления = TERMINAL_ARROWS.
        add(new Doc("plan_l5", "Level 5: Observation Posts", Style.OFFICIAL, List.of(
                new Head("LEVEL 5 / SESSION HALL"),                               // 0
                new Picture("plan_l5", 132),                                      // 1
                new Para("Posts are reviewed in numbered order."),                // 2
                new Stamp("COPY"))));                                             // 3
        add(new Doc("note_l3", "Page", Style.NOTE, List.of(
                new Para("it looks where they point."),                           // 0
                new Para("down here the list is read from the end."))));          // 1

        // Комната 47/48: приказ о переводе, код = время перевода 04:12. Лежит в лаборатории сна.
        add(new Doc("bay_transfer", "Transfer Order: Bays 47-48", Style.OFFICIAL, List.of(
                new Head("CRADLE RESEARCH FACILITY"),                              // 0
                new Para("Transfer of subjects 47 and 48 from the main catalog was approved at 04:12."), // 1
                new Para("Bay access code: 04:12."),                               // 2
                new Para("The room is not listed. Do not log the entrance."),      // 3
                new Stamp("RESTRICTED"))));                                        // 4
    }
}