package com.hypersomnia;

import com.hypersomnia.syringe.AdrenalineSyringeItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    private ModItems() {}

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(Hypersomnia.MOD_ID);

    public static final DeferredItem<Item> ADRENALINE_SYRINGE = ITEMS.register(
            "adrenaline_syringe",
            () -> new AdrenalineSyringeItem(new Item.Properties().stacksTo(8))
    );

    /** Один предмет на все страницы и воспоминания, id в custom_data. */
    public static final DeferredItem<Item> DOCUMENT = ITEMS.register(
            "document",
            () -> new com.hypersomnia.document.DocumentItem(new Item.Properties().stacksTo(1))
    );

    public static final DeferredItem<Item> DIARY = ITEMS.register(
            "diary",
            () -> new com.hypersomnia.document.DiaryItem(new Item.Properties().stacksTo(1))
    );
}
