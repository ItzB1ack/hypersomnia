package com.hypersomnia;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.neoforged.neoforge.common.util.INBTSerializable;

/** Прогресс для стадий осколка: прожитые дни и найденные воспоминания (битовая маска из 7). */
public class ObserverProgressData implements INBTSerializable<CompoundTag> {
    private int days;
    private int ticks;
    private int memories;
    /** Служебное: значения изменились, клиенту нужно отправить (не сохраняется). */
    private boolean dirty;
    /** Маска выданных записок слоя 1. */
    private int notes;
    /** Маска найденных рисунков Nora: биты 0-4 рисунки, бит 5 пустой лист (бонус). */
    private int drawings;
    /** Служебное: записка, выбранная при входе в сон и ждущая пробуждения (не сохраняется). */
    private int pendingNote = -1;
    private int pendingWay = -1;

    public int getDays() { return days; }
    public void setDays(int v) { days = Math.max(0, v); dirty = true; }
    public int getMemories() { return memories; }
    public int memoriesCount() { return Integer.bitCount(memories); }
    /** Заглушка до пункта 2: index 0..6 = номер воспоминания. */
    public void addMemory(int index) { memories |= 1 << index; dirty = true; }
    public void setMemoriesCount(int n) { memories = (1 << Math.max(0, Math.min(7, n))) - 1; dirty = true; }
    public void markDirty() { dirty = true; }
    public boolean consumeDirty() { boolean d = dirty; dirty = false; return d; }

    public int notesCount() { return Integer.bitCount(notes); }
    public boolean hasNote(int i) { return (notes & (1 << i)) != 0; }
    public void addNote(int i) { notes |= 1 << i; }
    public void resetNotes() { notes = 0; pendingNote = -1; pendingWay = -1; }

    public void addDrawing(int i) { drawings |= 1 << i; }
    public boolean hasDrawing(int i) { return (drawings & (1 << i)) != 0; }
    /** Найдено рисунков из условия секрета (без пустого листа). */
    public int drawingsCount() { return Integer.bitCount(drawings & ((1 << com.hypersomnia.document.DrawingTuning.COUNT) - 1)); }
    public boolean hasBlank() { return hasDrawing(com.hypersomnia.document.DrawingTuning.BLANK_INDEX); }
    /** Первая ещё не выданная страница, доступная на этой стадии, или -1. Страницы идут строго по порядку. */
    public int nextFreeNote(int stage) {
        for (int i = 0; i < ObserverTuning.NOTE_PAGES.length; i++) {
            if (hasNote(i)) continue;
            return stage >= ObserverTuning.NOTE_PAGE_MIN_STAGE[i] ? i : -1;
        }
        return -1;
    }
    public int getPendingNote() { return pendingNote; }
    public int getPendingWay() { return pendingWay; }
    public void setPending(int note, int way) { pendingNote = note; pendingWay = way; }
    public void clearPending() { pendingNote = -1; pendingWay = -1; }

    /** Один тик в Верхнем мире. true, если прошёл целый день. */
    public boolean addTick() {
        if (++ticks >= ObserverTuning.TICKS_PER_DAY) {
            ticks = 0;
            days++;
            dirty = true;
            return true;
        }
        return false;
    }

    @Override
    public CompoundTag serializeNBT(HolderLookup.Provider provider) {
        CompoundTag tag = new CompoundTag();
        tag.putInt("days", days);
        tag.putInt("ticks", ticks);
        tag.putInt("memories", memories);
        tag.putInt("notes", notes);
        tag.putInt("drawings", drawings);
        return tag;
    }

    @Override
    public void deserializeNBT(HolderLookup.Provider provider, CompoundTag tag) {
        days = Math.max(0, tag.getInt("days"));
        ticks = Math.max(0, tag.getInt("ticks"));
        memories = tag.getInt("memories") & 0x7F;
        notes = tag.getInt("notes");
        drawings = tag.getInt("drawings");
    }
}